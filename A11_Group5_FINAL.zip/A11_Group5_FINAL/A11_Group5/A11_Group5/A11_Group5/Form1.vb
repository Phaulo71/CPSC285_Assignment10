﻿'Martin Morales, Phaulo Escalante, Isaiah Soto, Eric Tellez
'Assignment 11
'4-28-2017

Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class driveSchoolForm
    Private RPhoneNumber As String
    Private RRealPhoneNumber As String
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Fill table adapters
        Me.InstructorsTableAdapter.Fill(Me.CPSC_285_5DataSet.Instructors)
        Me.StaffTableAdapter.Fill(Me.CPSC_285_5DataSet.Staff)
        Me.ClientTableAdapter.Fill(Me.CPSC_285_5DataSet.Client)

        'Update controls on load
        addClassTime()
        updateSchedule()
        WeekRbtn.Checked = True

        'Initializes the placeholders
        Me.RegistrationTxBxPlaceHolders()
    End Sub
    'CLIENTS TAB START

    'Update client class schedule
    Private Sub updateClasses()
        'Initialize grid view controller components (style)
        InitializeGridView()

        'Save student ID number
        Dim stuID As Int32
        If (ClientIDTextBox.Text <> "") Then
            stuID = ClientIDTextBox.Text
        End If

        'SQL server connection
        Dim cnnDriving As SqlConnection
        Dim strConnect As String = "Data Source=CISSQL;Initial Catalog=CPSC 285_5;Integrated Security=True"
        cnnDriving = New SqlConnection(strConnect)

        'SQL QUERY command begin
        Dim cmdClientSchedule As SqlCommand
        Dim rdrSQL As SqlDataReader

        'Open connection
        cnnDriving.Open()

        'Query to get all classes according to student ID
        Dim strSql As String = "SELECT Classes.Date, Classes.Time, Staff.Name " &
                               "FROM Classes,Client,Staff " &
                                "WHERE Classes.ClientID = Client.ClientID " &
                                    "AND Classes.StaffID = Staff.StaffID " &
                                    "AND Client.ClientID = " & stuID

        'Initiate SQL command
        cmdClientSchedule = New SqlCommand(strSql, cnnDriving)

        'Initiate SQL reader
        rdrSQL = cmdClientSchedule.ExecuteReader

        'Add rows read from SQL to grid view
        With rdrSQL
            If .HasRows Then
                Do While .Read
                    Dim cDay As DateTime = .Item(0)
                    Dim cTime As TimeSpan = .Item(1)

                    Dim row As String() = {cDay.ToString("d"), cTime.ToString("c"), .Item(2)}
                    gridSchedule.Rows.Add(row)
                Loop
            End If
        End With
    End Sub

    'Initialize schedule grid view style and columns
    Private Sub InitializeGridView()

        gridSchedule.ColumnCount = 3
        gridSchedule.ColumnHeadersVisible = True

        Dim ColumnHeaderStyle As DataGridViewCellStyle = New DataGridViewCellStyle
        ColumnHeaderStyle.BackColor = Color.Beige
        ColumnHeaderStyle.Font = New Font("Verdana", 10, FontStyle.Bold)
        gridSchedule.ColumnHeadersDefaultCellStyle = ColumnHeaderStyle

        gridSchedule.Columns(0).Name = "Date"
        gridSchedule.Columns(1).Name = "Time"
        gridSchedule.Columns(2).Name = "Instructor"
    End Sub

    'Update schedule grid when client ID is changed
    Private Sub ClientIDTextBox_TextChanged(sender As Object, e As EventArgs) Handles ClientIDTextBox.TextChanged
        gridSchedule.Rows.Clear()
        updateClasses()
    End Sub
    'END OF CLIENTS TAB

    'START OF REGISTRATION FORM TAB
    Private Sub TabResize(sender As Object, e As EventArgs) Handles MyBase.Resize
        SchoolTabControl.Size = Me.Size
    End Sub

    Private Sub RegistrationPhoneNumber()
        RPhoneNumber = rPhoneNumTxtBx.Text
        For i = 0 To RPhoneNumber.Length - 1
            If (RPhoneNumber.ToUpper.Chars(i) = "A" Or RPhoneNumber.ToUpper.Chars(i) = "B" Or RPhoneNumber.ToUpper.Chars(i) = "C") Then
                RRealPhoneNumber += "2"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "D" Or RPhoneNumber.ToUpper.Chars(i) = "E" Or RPhoneNumber.ToUpper.Chars(i) = "F") Then
                RRealPhoneNumber += "3"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "G" Or RPhoneNumber.ToUpper.Chars(i) = "H" Or RPhoneNumber.ToUpper.Chars(i) = "I") Then
                RRealPhoneNumber += "4"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "J" Or RPhoneNumber.ToUpper.Chars(i) = "K" Or RPhoneNumber.ToUpper.Chars(i) = "L") Then
                RRealPhoneNumber += "5"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "M" Or RPhoneNumber.ToUpper.Chars(i) = "N" Or RPhoneNumber.ToUpper.Chars(i) = "O") Then
                RRealPhoneNumber += "6"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "P" Or RPhoneNumber.ToUpper.Chars(i) = "Q" Or RPhoneNumber.ToUpper.Chars(i) = "R" Or RPhoneNumber.ToUpper.Chars(i) = "S") Then
                RRealPhoneNumber += "7"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "T" Or RPhoneNumber.ToUpper.Chars(i) = "U" Or RPhoneNumber.ToUpper.Chars(i) = "V") Then
                RRealPhoneNumber += "8"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "W" Or RPhoneNumber.ToUpper.Chars(i) = "X" Or RPhoneNumber.ToUpper.Chars(i) = "Y" Or RPhoneNumber.ToUpper.Chars(i) = "Z") Then
                RRealPhoneNumber += "9"
            ElseIf (Char.IsNumber(RPhoneNumber.Chars(i))) Then
                If (RPhoneNumber.Chars(i) <> "1" And i = 0) Then
                    RRealPhoneNumber += "1" & RPhoneNumber.Chars(i)
                Else
                    RRealPhoneNumber += RPhoneNumber.Chars(i)
                End If
            End If
        Next
    End Sub

    'Placeholders
    Private Sub RegistrationTxBxPlaceHolders()
        rDobTxtBx.Text = "MM-DD-YYYY"
        rDobTxtBx.ForeColor = Color.Gray
        rPhoneNumTxtBx.Text = "#-###-###-####"
        rPhoneNumTxtBx.ForeColor = Color.Gray
    End Sub

    'Gets rid of the place holder for DOB
    Private Sub rDOBFocus(sender As Object, e As EventArgs) Handles rDobTxtBx.Enter
        If (rDobTxtBx.Text = "MM-DD-YYYY") Then
            rDobTxtBx.Text = ""
            rDobTxtBx.ForeColor = Color.Black
        End If
    End Sub

    'Placeholder for Date of Birth text box if nothing is inputed
    Private Sub rDOBFocusLeft(sender As Object, e As EventArgs) Handles rDobTxtBx.Leave
        If (rDobTxtBx.Text = "") Then
            rDobTxtBx.Text = "MM-DD-YYYY"
            rDobTxtBx.ForeColor = Color.Gray
        End If
    End Sub

    'Gets rid of the placeholder for Phone Number text box
    Private Sub rphoneNumFocus(sender As Object, e As EventArgs) Handles rPhoneNumTxtBx.Enter
        If (rPhoneNumTxtBx.Text = "#-###-###-####") Then
            rPhoneNumTxtBx.Text = ""
            rPhoneNumTxtBx.ForeColor = Color.Black
        End If
    End Sub

    'Placeholder for phone number if nothing has been inputed
    Private Sub rPhoneNumFocusLeft(sender As Object, e As EventArgs) Handles rPhoneNumTxtBx.Leave
        If (rPhoneNumTxtBx.Text = "") Then
            rPhoneNumTxtBx.Text = "#-###-###-####"
            rPhoneNumTxtBx.ForeColor = Color.Gray
        End If
    End Sub

    'Registration form radio button checking method
    Private Sub MaritalStatusRB(sender As Object, e As EventArgs) Handles MyBase.Resize, RSingleRadioBtn.CheckedChanged, RMarryRadioBtn.CheckedChanged
        If (RMarryRadioBtn.Checked = True) Then
            RSingleRadioBtn.Checked = False
        ElseIf (RSingleRadioBtn.Checked = True) Then
            RMarryRadioBtn.Checked = False
        End If

    End Sub
    'Called when register button is pressed
    Private Sub RRegisterBtn_Click(sender As Object, e As EventArgs) Handles RRegisterBtn.Click
        Dim fName As String = rFNameTxtBx.Text
        Dim lName As String = rLNameTxtBx.Text
        Dim name As String = fName & " " & lName
        Dim maritalStat As Boolean
        Dim phoneNum As String
        RegistrationPhoneNumber()

        If (RRealPhoneNumber.Length() <> 0) Then
            If (RRealPhoneNumber.Length() = 11) Then
                phoneNum = Format(Convert.ToInt64(RRealPhoneNumber), "#-(###) ###-####")
            End If
        End If

        If (fName <> "" And lName <> "" And rDobTxtBx.Text <> "MM-DD-YYYY" And rPhoneNumTxtBx.Text <> "#-###-###-####" And RRealPhoneNumber.Length() = 11) Then
            Dim dob As String = CDate(rDobTxtBx.Text).ToString("yyyy-MM-dd")
            Dim cnnClient As SqlConnection
            Dim strConnect As String = "Data Source=CISSQL;Initial Catalog=CPSC 285_5;Integrated Security=True"
            cnnClient = New SqlConnection(strConnect)

            Dim cmdNewClient As SqlCommand
            Dim rdrSQL As SqlDataReader

            If (RMarryRadioBtn.Checked = True) Then
                maritalStat = True
            ElseIf (RSingleRadioBtn.Checked = True) Then
                maritalStat = False
            End If

            Dim strSQL As String = "Insert Into Client (Name, [Marital Status], [Date of Birth], [Phone #]) " &
                               "Values ('" & name & "', '" & maritalStat & "', '" & dob & "', '" & phoneNum & "')"
            Try
                cnnClient = New SqlConnection(strConnect)
                cnnClient.Open()

                cmdNewClient = New SqlCommand
                cmdNewClient.Connection = cnnClient
                cmdNewClient.CommandText = strSQL
                cmdNewClient.CommandType = CommandType.Text

                If (cmdNewClient.ExecuteNonQuery().Equals(1)) Then
                    MessageBox.Show(name & " has been registered.")
                Else
                    MessageBox.Show("Could not register!")
                End If
                cnnClient.Close()
                Me.ClientTableAdapter.Fill(Me.CPSC_285_5DataSet.Client)

                'Resets the form
                rFNameTxtBx.Text = " "
                rLNameTxtBx.Text = " "
                RegistrationTxBxPlaceHolders()
                RMarryRadioBtn.Checked = True
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
        'Rresets the RRealPhoneNumber
        RRealPhoneNumber = ""
    End Sub
    Private Sub ClientBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ClientBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ClientBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CPSC_285_5DataSet)

    End Sub
    'Start of Staff Tab
    Private Sub updateSchedule()
        InitializeGridView2()
        'gets the staff name
        Dim staffName As String = NameComboBox.Text

        'Sql Connection
        Dim cnnDriving As SqlConnection
        Dim strConnect As String = "Data Source=CISSQL;Initial Catalog=CPSC 285_5;Integrated Security=True"
        cnnDriving = New SqlConnection(strConnect)

        Dim cmdStaffSchedule As SqlCommand
        Dim rdrSQL As SqlDataReader

        cnnDriving.Open()
        Dim strSql As String
        'Checks which radio button is checked to show the apporpriate info 
        'day
        If DayRbtn.Checked Then
            strSql = "SELECT Classes.Date, Classes.Time, Client.Name " &
                 "FROM Classes,Client,Staff " &
                 "WHERE Classes.ClientID = Client.ClientID " &
                 "AND Classes.StaffID = Staff.StaffID " &
                 "AND Staff.Name = '" & staffName & "'" &
                 "AND Classes.Date = CONVERT(char(10), GetDate(),126)"
            'week
        ElseIf WeekRbtn.Checked Then
            strSql = "SELECT Classes.Date, Classes.Time, Client.Name " &
                "FROM Classes,Client,Staff " &
                "WHERE Classes.ClientID = Client.ClientID " &
                "AND Classes.StaffID = Staff.StaffID " &
                "AND Staff.Name = '" & staffName & "'" &
                "AND Classes.Date <= GetDate()+6" &
                "And Classes.Date >= GetDate()"
        Else
            'month
            strSql = "SELECT Classes.Date, Classes.Time, Client.Name " &
               "FROM Classes,Client,Staff " &
               "WHERE Classes.ClientID = Client.ClientID " &
               "AND Classes.StaffID = Staff.StaffID " &
               "AND Staff.Name = '" & staffName & "'" &
               "AND Classes.Date <= GetDate()+29" &
               "And Classes.Date >= GetDate()"
        End If


        cmdStaffSchedule = New SqlCommand(strSql, cnnDriving)

        rdrSQL = cmdStaffSchedule.ExecuteReader

        'Fills DataGridView with info
        With rdrSQL
            If .HasRows Then
                Do While .Read
                    Dim cDay As DateTime = .Item(0)
                    Dim cTime As TimeSpan = .Item(1)

                    Dim row As String() = {cDay.ToString("d"), cTime.ToString("c"), .Item(2)}
                    StaffScheduleGrid.Rows.Add(row)
                Loop
            End If

        End With

    End Sub

    Private Sub InitializeGridView2()
        'Fills the Data Grid view with template
        StaffScheduleGrid.ColumnCount = 3
        StaffScheduleGrid.ColumnHeadersVisible = True

        Dim ColumnHeaderStyle As DataGridViewCellStyle = New DataGridViewCellStyle
        ColumnHeaderStyle.BackColor = Color.Beige
        ColumnHeaderStyle.Font = New Font("Verdana", 10, FontStyle.Bold)
        StaffScheduleGrid.ColumnHeadersDefaultCellStyle = ColumnHeaderStyle

        StaffScheduleGrid.Columns(0).Name = "Date"
        StaffScheduleGrid.Columns(1).Name = "Time"
        StaffScheduleGrid.Columns(2).Name = "Client"

    End Sub
    Private Sub NameComboBox_TextChanged(sender As Object, e As EventArgs) Handles NameComboBox.TextChanged
        'refreshes the radio button choice
        StaffScheduleGrid.Rows.Clear()
        updateSchedule()
    End Sub

    Private Sub MonthRbtn_CheckedChanged(sender As Object, e As EventArgs) Handles MonthRbtn.CheckedChanged
        'refreshes the radio button choice
        StaffScheduleGrid.Rows.Clear()
        updateSchedule()
    End Sub

    Private Sub DayRbtn_CheckedChanged(sender As Object, e As EventArgs) Handles DayRbtn.CheckedChanged
        'refreshes the radio button choice
        StaffScheduleGrid.Rows.Clear()
        updateSchedule()
    End Sub

    Private Sub WeekRbtn_CheckedChanged(sender As Object, e As EventArgs) Handles WeekRbtn.CheckedChanged
        'refreshes the radio button choice
        StaffScheduleGrid.Rows.Clear()
        updateSchedule()
    End Sub
    'End of Staff Tab'
    'Start of Add Class'
    Private Sub addClassTime()

        Dim stuID As Int32 = ClientIDTextBox.Text
        'The Sql Connection
        Dim cnnDriving As SqlConnection
        Dim strConnect As String = "Data Source=CISSQL;Initial Catalog=CPSC 285_5;Integrated Security=True"
        cnnDriving = New SqlConnection(strConnect)

        Dim cmdClientSchedule As SqlCommand
        Dim rdrSQL As SqlDataReader

        'Gets info from instructors drop down
        Dim row_v As DataRowView = Instructors.SelectedItem
        Dim row As DataRow = row_v.Row
        Dim itemName As String = row(0).ToString

        cnnDriving.Open()
        'Sql statement
        Dim strSql As String = "SELECT CLASSES.TIME " &
                               "FROM CLIENT RIGHT OUTER JOIN (CLASSES INNER JOIN STAFF ON CLASSES.STAFFID = STAFF.STAFFID ) ON CLASSES.CLIENTID = CLIENT.CLIENTID " &
                               "WHERE STAFF.NAME = '" & itemName & "' AND Classes.ClientID IS NULL " &
                               "AND CLASSES.DATE = '" & ClassDate.Value.ToShortDateString & "'"
        cmdClientSchedule = New SqlCommand(strSql, cnnDriving)

        rdrSQL = cmdClientSchedule.ExecuteReader
        'Fills The combobox with available times
        With rdrSQL
            If .HasRows Then
                Do While .Read
                    Dim cTime As TimeSpan = .Item(0)
                    Console.WriteLine(.Item(0).ToString)
                    ClassTime.Items.Add(cTime.ToString("c"))
                Loop
            End If
        End With
    End Sub
    Private Sub ClassDate_ValueChanged(sender As Object, e As EventArgs) Handles ClassDate.ValueChanged
        'Does not allow weekends to be chosen
        If ClassDate.Value.DayOfWeek = 0 Or ClassDate.Value.DayOfWeek = 6 Then
            MessageBox.Show("Classes are not held on weekends, please select a weekday")
            ClassDate.Value = "2017-4-27"
        Else
            'Clears and refreshes data when the info is changed
            ClassTime.Items.Clear()
            addClassTime()
        End If
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        'Collects the instructors data
        Dim row_v As DataRowView = Instructors.SelectedItem
        Dim row As DataRow = row_v.Row
        Dim instructor As String = row(0).ToString
        'Collects the ClassDay 
        Dim classDay As String = CDate(ClassDate.Value).ToString("yyyy-MM-dd")
        'Collects class time
        Dim classTi As String = ClassTime.SelectedItem.ToString()
        'Collects currents client ID
        Dim clientID As Int32 = Integer.Parse(ClientIDTextBox.Text)
        'If time is blank, does nothing
        If IsNothing(classTi) Then
            MessageBox.Show("Please Enter A Time")
        Else
            'Sql Connection
            Dim cnnClass As SqlConnection
            Dim strConnect As String = "Data Source=CISSQL;Initial Catalog=CPSC 285_5;Integrated Security=True"
            cnnClass = New SqlConnection(strConnect)

            Dim cmdNewClass As SqlCommand
            'Sql statement, Updates with new client
            Dim strSQL As String = "UPDATE Classes " &
                                    "SET CLIENTID = " & clientID &
                                    " WHERE CLASSES.DATE = '" & classDay & "'" &
                                        " And CLASSES.Time = '" & classTi & "'" &
                                        " And CLASSES.STAFFID IN " &
                                                "(SELECT STAFFID" &
                                                " From STAFF" &
                                                " WHERE NAME = '" & instructor & "')"
            Try
                cnnClass = New SqlConnection(strConnect)
                cnnClass.Open()

                cmdNewClass = New SqlCommand
                cmdNewClass.Connection = cnnClass
                cmdNewClass.CommandText = strSQL
                cmdNewClass.CommandType = CommandType.Text

                If (cmdNewClass.ExecuteNonQuery().Equals(1)) Then
                    MessageBox.Show("Class has been registered.")
                Else
                    MessageBox.Show("Could not register!")
                End If
                cnnClass.Close()
                Me.ClientTableAdapter.Fill(Me.CPSC_285_5DataSet.Client)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub
    Private Sub Instructors_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Instructors.SelectedIndexChanged
        'Checks When the instructors is changed
        ClassTime.Items.Clear()
        addClassTime()
    End Sub
    'End of Add Class Tab'
End Class

