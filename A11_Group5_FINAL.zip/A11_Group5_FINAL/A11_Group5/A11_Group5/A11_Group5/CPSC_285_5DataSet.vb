﻿Partial Class CPSC_285_5DataSet
End Class

Namespace CPSC_285_5DataSetTableAdapters
    Partial Public Class ClassesTableAdapter
    End Class
End Namespace
