﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class driveSchoolForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ClientIDLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(driveSchoolForm))
        Dim NameLabel As System.Windows.Forms.Label
        Dim Marital_StatusLabel As System.Windows.Forms.Label
        Dim Date_of_BirthLabel As System.Windows.Forms.Label
        Dim Phone__Label As System.Windows.Forms.Label
        Dim NameLabel1 As System.Windows.Forms.Label
        Dim StaffIDLabel As System.Windows.Forms.Label
        Dim PositionLabel As System.Windows.Forms.Label
        Dim Phone__Label1 As System.Windows.Forms.Label
        Me.ToolStripContainer1 = New System.Windows.Forms.ToolStripContainer()
        Me.ClientBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.ClientBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CPSC_285_5DataSet = New A11_Group5.CPSC_285_5DataSet()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ClientBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.SchoolTabControl = New System.Windows.Forms.TabControl()
        Me.tabClientNav = New System.Windows.Forms.TabPage()
        Me.gridSchedule = New System.Windows.Forms.DataGridView()
        Me.chkMarried = New System.Windows.Forms.CheckBox()
        Me.ClientIDTextBox = New System.Windows.Forms.TextBox()
        Me.NameTextBox = New System.Windows.Forms.TextBox()
        Me.Date_of_BirthDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Phone__TextBox = New System.Windows.Forms.TextBox()
        Me.lblClients = New System.Windows.Forms.Label()
        Me.tabRegistration = New System.Windows.Forms.TabPage()
        Me.rPhoneNumTxtBx = New System.Windows.Forms.TextBox()
        Me.rDobTxtBx = New System.Windows.Forms.TextBox()
        Me.rLNameTxtBx = New System.Windows.Forms.TextBox()
        Me.rFNameTxtBx = New System.Windows.Forms.TextBox()
        Me.RRegisterBtn = New System.Windows.Forms.Button()
        Me.RMaritalStatLbl = New System.Windows.Forms.Label()
        Me.RSingleRadioBtn = New System.Windows.Forms.RadioButton()
        Me.RMarryRadioBtn = New System.Windows.Forms.RadioButton()
        Me.RTitle = New System.Windows.Forms.Label()
        Me.RTelNumLbl = New System.Windows.Forms.Label()
        Me.RDobLbl = New System.Windows.Forms.Label()
        Me.RLastNmLb = New System.Windows.Forms.Label()
        Me.RFirstNmLb = New System.Windows.Forms.Label()
        Me.tabStaff = New System.Windows.Forms.TabPage()
        Me.BindingNavigator1 = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem1 = New System.Windows.Forms.ToolStripButton()
        Me.StaffBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BindingNavigatorCountItem1 = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem1 = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.Phone__TextBox1 = New System.Windows.Forms.TextBox()
        Me.PositionTextBox = New System.Windows.Forms.TextBox()
        Me.StaffIDTextBox = New System.Windows.Forms.TextBox()
        Me.NameComboBox = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.MonthRbtn = New System.Windows.Forms.RadioButton()
        Me.WeekRbtn = New System.Windows.Forms.RadioButton()
        Me.DayRbtn = New System.Windows.Forms.RadioButton()
        Me.StaffScheduleGrid = New System.Windows.Forms.DataGridView()
        Me.tabAddClass = New System.Windows.Forms.TabPage()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.ClassTime = New System.Windows.Forms.ComboBox()
        Me.ClassDate = New System.Windows.Forms.DateTimePicker()
        Me.Instructors = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ClientTableAdapter = New A11_Group5.CPSC_285_5DataSetTableAdapters.ClientTableAdapter()
        Me.TableAdapterManager = New A11_Group5.CPSC_285_5DataSetTableAdapters.TableAdapterManager()
        Me.StaffTableAdapter = New A11_Group5.CPSC_285_5DataSetTableAdapters.StaffTableAdapter()
        Me.ClassesTableAdapter = New A11_Group5.CPSC_285_5DataSetTableAdapters.ClassesTableAdapter()
        Me.InstructorsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.InstructorsTableAdapter = New A11_Group5.CPSC_285_5DataSetTableAdapters.InstructorsTableAdapter()
        ClientIDLabel = New System.Windows.Forms.Label()
        NameLabel = New System.Windows.Forms.Label()
        Marital_StatusLabel = New System.Windows.Forms.Label()
        Date_of_BirthLabel = New System.Windows.Forms.Label()
        Phone__Label = New System.Windows.Forms.Label()
        NameLabel1 = New System.Windows.Forms.Label()
        StaffIDLabel = New System.Windows.Forms.Label()
        PositionLabel = New System.Windows.Forms.Label()
        Phone__Label1 = New System.Windows.Forms.Label()
        Me.ToolStripContainer1.BottomToolStripPanel.SuspendLayout()
        Me.ToolStripContainer1.SuspendLayout()
        CType(Me.ClientBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ClientBindingNavigator.SuspendLayout()
        CType(Me.ClientBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CPSC_285_5DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SchoolTabControl.SuspendLayout()
        Me.tabClientNav.SuspendLayout()
        CType(Me.gridSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabRegistration.SuspendLayout()
        Me.tabStaff.SuspendLayout()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BindingNavigator1.SuspendLayout()
        CType(Me.StaffBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.StaffScheduleGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabAddClass.SuspendLayout()
        CType(Me.InstructorsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ClientIDLabel
        '
        resources.ApplyResources(ClientIDLabel, "ClientIDLabel")
        ClientIDLabel.Name = "ClientIDLabel"
        '
        'ToolStripContainer1
        '
        '
        'ToolStripContainer1.BottomToolStripPanel
        '
        Me.ToolStripContainer1.BottomToolStripPanel.Controls.Add(Me.ClientBindingNavigator)
        '
        'ToolStripContainer1.ContentPanel
        '
        resources.ApplyResources(Me.ToolStripContainer1.ContentPanel, "ToolStripContainer1.ContentPanel")
        resources.ApplyResources(Me.ToolStripContainer1, "ToolStripContainer1")
        Me.ToolStripContainer1.Name = "ToolStripContainer1"
        '
        'ClientBindingNavigator
        '
        Me.ClientBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.ClientBindingNavigator.BindingSource = Me.ClientBindingSource
        Me.ClientBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.ClientBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        resources.ApplyResources(Me.ClientBindingNavigator, "ClientBindingNavigator")
        Me.ClientBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.ClientBindingNavigatorSaveItem})
        Me.ClientBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.ClientBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.ClientBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.ClientBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.ClientBindingNavigator.Name = "ClientBindingNavigator"
        Me.ClientBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorAddNewItem, "BindingNavigatorAddNewItem")
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        '
        'ClientBindingSource
        '
        Me.ClientBindingSource.DataMember = "Client"
        Me.ClientBindingSource.DataSource = Me.CPSC_285_5DataSet
        '
        'CPSC_285_5DataSet
        '
        Me.CPSC_285_5DataSet.DataSetName = "CPSC_285_5DataSet"
        Me.CPSC_285_5DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        resources.ApplyResources(Me.BindingNavigatorCountItem, "BindingNavigatorCountItem")
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorDeleteItem, "BindingNavigatorDeleteItem")
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMoveFirstItem, "BindingNavigatorMoveFirstItem")
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMovePreviousItem, "BindingNavigatorMovePreviousItem")
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        resources.ApplyResources(Me.BindingNavigatorSeparator, "BindingNavigatorSeparator")
        '
        'BindingNavigatorPositionItem
        '
        resources.ApplyResources(Me.BindingNavigatorPositionItem, "BindingNavigatorPositionItem")
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        resources.ApplyResources(Me.BindingNavigatorSeparator1, "BindingNavigatorSeparator1")
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMoveNextItem, "BindingNavigatorMoveNextItem")
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMoveLastItem, "BindingNavigatorMoveLastItem")
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        resources.ApplyResources(Me.BindingNavigatorSeparator2, "BindingNavigatorSeparator2")
        '
        'ClientBindingNavigatorSaveItem
        '
        Me.ClientBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.ClientBindingNavigatorSaveItem, "ClientBindingNavigatorSaveItem")
        Me.ClientBindingNavigatorSaveItem.Name = "ClientBindingNavigatorSaveItem"
        '
        'NameLabel
        '
        resources.ApplyResources(NameLabel, "NameLabel")
        NameLabel.Name = "NameLabel"
        '
        'Marital_StatusLabel
        '
        resources.ApplyResources(Marital_StatusLabel, "Marital_StatusLabel")
        Marital_StatusLabel.Name = "Marital_StatusLabel"
        '
        'Date_of_BirthLabel
        '
        resources.ApplyResources(Date_of_BirthLabel, "Date_of_BirthLabel")
        Date_of_BirthLabel.Name = "Date_of_BirthLabel"
        '
        'Phone__Label
        '
        resources.ApplyResources(Phone__Label, "Phone__Label")
        Phone__Label.Name = "Phone__Label"
        '
        'NameLabel1
        '
        resources.ApplyResources(NameLabel1, "NameLabel1")
        NameLabel1.Name = "NameLabel1"
        '
        'StaffIDLabel
        '
        resources.ApplyResources(StaffIDLabel, "StaffIDLabel")
        StaffIDLabel.Name = "StaffIDLabel"
        '
        'PositionLabel
        '
        resources.ApplyResources(PositionLabel, "PositionLabel")
        PositionLabel.Name = "PositionLabel"
        '
        'Phone__Label1
        '
        resources.ApplyResources(Phone__Label1, "Phone__Label1")
        Phone__Label1.Name = "Phone__Label1"
        '
        'SchoolTabControl
        '
        Me.SchoolTabControl.Controls.Add(Me.tabClientNav)
        Me.SchoolTabControl.Controls.Add(Me.tabRegistration)
        Me.SchoolTabControl.Controls.Add(Me.tabStaff)
        Me.SchoolTabControl.Controls.Add(Me.tabAddClass)
        resources.ApplyResources(Me.SchoolTabControl, "SchoolTabControl")
        Me.SchoolTabControl.Name = "SchoolTabControl"
        Me.SchoolTabControl.SelectedIndex = 0
        '
        'tabClientNav
        '
        Me.tabClientNav.Controls.Add(Me.gridSchedule)
        Me.tabClientNav.Controls.Add(Me.ToolStripContainer1)
        Me.tabClientNav.Controls.Add(Me.chkMarried)
        Me.tabClientNav.Controls.Add(ClientIDLabel)
        Me.tabClientNav.Controls.Add(Me.ClientIDTextBox)
        Me.tabClientNav.Controls.Add(NameLabel)
        Me.tabClientNav.Controls.Add(Me.NameTextBox)
        Me.tabClientNav.Controls.Add(Marital_StatusLabel)
        Me.tabClientNav.Controls.Add(Date_of_BirthLabel)
        Me.tabClientNav.Controls.Add(Me.Date_of_BirthDateTimePicker)
        Me.tabClientNav.Controls.Add(Phone__Label)
        Me.tabClientNav.Controls.Add(Me.Phone__TextBox)
        Me.tabClientNav.Controls.Add(Me.lblClients)
        resources.ApplyResources(Me.tabClientNav, "tabClientNav")
        Me.tabClientNav.Name = "tabClientNav"
        Me.tabClientNav.UseVisualStyleBackColor = True
        '
        'gridSchedule
        '
        Me.gridSchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        resources.ApplyResources(Me.gridSchedule, "gridSchedule")
        Me.gridSchedule.Name = "gridSchedule"
        Me.gridSchedule.ReadOnly = True
        '
        'chkMarried
        '
        resources.ApplyResources(Me.chkMarried, "chkMarried")
        Me.chkMarried.Checked = True
        Me.chkMarried.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkMarried.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.ClientBindingSource, "Marital Status", True))
        Me.chkMarried.Name = "chkMarried"
        Me.chkMarried.UseVisualStyleBackColor = True
        '
        'ClientIDTextBox
        '
        Me.ClientIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClientBindingSource, "ClientID", True))
        resources.ApplyResources(Me.ClientIDTextBox, "ClientIDTextBox")
        Me.ClientIDTextBox.Name = "ClientIDTextBox"
        Me.ClientIDTextBox.ReadOnly = True
        '
        'NameTextBox
        '
        Me.NameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClientBindingSource, "Name", True))
        resources.ApplyResources(Me.NameTextBox, "NameTextBox")
        Me.NameTextBox.Name = "NameTextBox"
        Me.NameTextBox.ReadOnly = True
        '
        'Date_of_BirthDateTimePicker
        '
        Me.Date_of_BirthDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.ClientBindingSource, "Date of Birth", True))
        resources.ApplyResources(Me.Date_of_BirthDateTimePicker, "Date_of_BirthDateTimePicker")
        Me.Date_of_BirthDateTimePicker.Name = "Date_of_BirthDateTimePicker"
        '
        'Phone__TextBox
        '
        Me.Phone__TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClientBindingSource, "Phone #", True))
        resources.ApplyResources(Me.Phone__TextBox, "Phone__TextBox")
        Me.Phone__TextBox.Name = "Phone__TextBox"
        Me.Phone__TextBox.ReadOnly = True
        '
        'lblClients
        '
        resources.ApplyResources(Me.lblClients, "lblClients")
        Me.lblClients.Name = "lblClients"
        '
        'tabRegistration
        '
        Me.tabRegistration.Controls.Add(Me.rPhoneNumTxtBx)
        Me.tabRegistration.Controls.Add(Me.rDobTxtBx)
        Me.tabRegistration.Controls.Add(Me.rLNameTxtBx)
        Me.tabRegistration.Controls.Add(Me.rFNameTxtBx)
        Me.tabRegistration.Controls.Add(Me.RRegisterBtn)
        Me.tabRegistration.Controls.Add(Me.RMaritalStatLbl)
        Me.tabRegistration.Controls.Add(Me.RSingleRadioBtn)
        Me.tabRegistration.Controls.Add(Me.RMarryRadioBtn)
        Me.tabRegistration.Controls.Add(Me.RTitle)
        Me.tabRegistration.Controls.Add(Me.RTelNumLbl)
        Me.tabRegistration.Controls.Add(Me.RDobLbl)
        Me.tabRegistration.Controls.Add(Me.RLastNmLb)
        Me.tabRegistration.Controls.Add(Me.RFirstNmLb)
        resources.ApplyResources(Me.tabRegistration, "tabRegistration")
        Me.tabRegistration.Name = "tabRegistration"
        Me.tabRegistration.UseVisualStyleBackColor = True
        '
        'rPhoneNumTxtBx
        '
        resources.ApplyResources(Me.rPhoneNumTxtBx, "rPhoneNumTxtBx")
        Me.rPhoneNumTxtBx.Name = "rPhoneNumTxtBx"
        '
        'rDobTxtBx
        '
        resources.ApplyResources(Me.rDobTxtBx, "rDobTxtBx")
        Me.rDobTxtBx.Name = "rDobTxtBx"
        '
        'rLNameTxtBx
        '
        resources.ApplyResources(Me.rLNameTxtBx, "rLNameTxtBx")
        Me.rLNameTxtBx.Name = "rLNameTxtBx"
        '
        'rFNameTxtBx
        '
        resources.ApplyResources(Me.rFNameTxtBx, "rFNameTxtBx")
        Me.rFNameTxtBx.Name = "rFNameTxtBx"
        '
        'RRegisterBtn
        '
        resources.ApplyResources(Me.RRegisterBtn, "RRegisterBtn")
        Me.RRegisterBtn.Name = "RRegisterBtn"
        Me.RRegisterBtn.UseVisualStyleBackColor = True
        '
        'RMaritalStatLbl
        '
        resources.ApplyResources(Me.RMaritalStatLbl, "RMaritalStatLbl")
        Me.RMaritalStatLbl.Name = "RMaritalStatLbl"
        '
        'RSingleRadioBtn
        '
        resources.ApplyResources(Me.RSingleRadioBtn, "RSingleRadioBtn")
        Me.RSingleRadioBtn.Name = "RSingleRadioBtn"
        Me.RSingleRadioBtn.UseVisualStyleBackColor = True
        '
        'RMarryRadioBtn
        '
        resources.ApplyResources(Me.RMarryRadioBtn, "RMarryRadioBtn")
        Me.RMarryRadioBtn.Checked = True
        Me.RMarryRadioBtn.Name = "RMarryRadioBtn"
        Me.RMarryRadioBtn.TabStop = True
        Me.RMarryRadioBtn.UseVisualStyleBackColor = True
        '
        'RTitle
        '
        resources.ApplyResources(Me.RTitle, "RTitle")
        Me.RTitle.Name = "RTitle"
        '
        'RTelNumLbl
        '
        resources.ApplyResources(Me.RTelNumLbl, "RTelNumLbl")
        Me.RTelNumLbl.Name = "RTelNumLbl"
        '
        'RDobLbl
        '
        resources.ApplyResources(Me.RDobLbl, "RDobLbl")
        Me.RDobLbl.Name = "RDobLbl"
        '
        'RLastNmLb
        '
        resources.ApplyResources(Me.RLastNmLb, "RLastNmLb")
        Me.RLastNmLb.Name = "RLastNmLb"
        '
        'RFirstNmLb
        '
        resources.ApplyResources(Me.RFirstNmLb, "RFirstNmLb")
        Me.RFirstNmLb.Name = "RFirstNmLb"
        '
        'tabStaff
        '
        resources.ApplyResources(Me.tabStaff, "tabStaff")
        Me.tabStaff.Controls.Add(Me.BindingNavigator1)
        Me.tabStaff.Controls.Add(Phone__Label1)
        Me.tabStaff.Controls.Add(Me.Phone__TextBox1)
        Me.tabStaff.Controls.Add(PositionLabel)
        Me.tabStaff.Controls.Add(Me.PositionTextBox)
        Me.tabStaff.Controls.Add(StaffIDLabel)
        Me.tabStaff.Controls.Add(Me.StaffIDTextBox)
        Me.tabStaff.Controls.Add(NameLabel1)
        Me.tabStaff.Controls.Add(Me.NameComboBox)
        Me.tabStaff.Controls.Add(Me.Label1)
        Me.tabStaff.Controls.Add(Me.GroupBox1)
        Me.tabStaff.Controls.Add(Me.StaffScheduleGrid)
        Me.tabStaff.Name = "tabStaff"
        Me.tabStaff.UseVisualStyleBackColor = True
        '
        'BindingNavigator1
        '
        Me.BindingNavigator1.AddNewItem = Me.BindingNavigatorAddNewItem1
        Me.BindingNavigator1.BindingSource = Me.StaffBindingSource
        Me.BindingNavigator1.CountItem = Me.BindingNavigatorCountItem1
        Me.BindingNavigator1.DeleteItem = Me.BindingNavigatorDeleteItem1
        Me.BindingNavigator1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem1, Me.BindingNavigatorMovePreviousItem1, Me.BindingNavigatorSeparator3, Me.BindingNavigatorPositionItem1, Me.BindingNavigatorCountItem1, Me.BindingNavigatorSeparator4, Me.BindingNavigatorMoveNextItem1, Me.BindingNavigatorMoveLastItem1, Me.BindingNavigatorSeparator5, Me.BindingNavigatorAddNewItem1, Me.BindingNavigatorDeleteItem1})
        resources.ApplyResources(Me.BindingNavigator1, "BindingNavigator1")
        Me.BindingNavigator1.MoveFirstItem = Me.BindingNavigatorMoveFirstItem1
        Me.BindingNavigator1.MoveLastItem = Me.BindingNavigatorMoveLastItem1
        Me.BindingNavigator1.MoveNextItem = Me.BindingNavigatorMoveNextItem1
        Me.BindingNavigator1.MovePreviousItem = Me.BindingNavigatorMovePreviousItem1
        Me.BindingNavigator1.Name = "BindingNavigator1"
        Me.BindingNavigator1.PositionItem = Me.BindingNavigatorPositionItem1
        '
        'BindingNavigatorAddNewItem1
        '
        Me.BindingNavigatorAddNewItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorAddNewItem1, "BindingNavigatorAddNewItem1")
        Me.BindingNavigatorAddNewItem1.Name = "BindingNavigatorAddNewItem1"
        '
        'StaffBindingSource
        '
        Me.StaffBindingSource.DataMember = "Staff"
        Me.StaffBindingSource.DataSource = Me.CPSC_285_5DataSet
        '
        'BindingNavigatorCountItem1
        '
        Me.BindingNavigatorCountItem1.Name = "BindingNavigatorCountItem1"
        resources.ApplyResources(Me.BindingNavigatorCountItem1, "BindingNavigatorCountItem1")
        '
        'BindingNavigatorDeleteItem1
        '
        Me.BindingNavigatorDeleteItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorDeleteItem1, "BindingNavigatorDeleteItem1")
        Me.BindingNavigatorDeleteItem1.Name = "BindingNavigatorDeleteItem1"
        '
        'BindingNavigatorMoveFirstItem1
        '
        Me.BindingNavigatorMoveFirstItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMoveFirstItem1, "BindingNavigatorMoveFirstItem1")
        Me.BindingNavigatorMoveFirstItem1.Name = "BindingNavigatorMoveFirstItem1"
        '
        'BindingNavigatorMovePreviousItem1
        '
        Me.BindingNavigatorMovePreviousItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMovePreviousItem1, "BindingNavigatorMovePreviousItem1")
        Me.BindingNavigatorMovePreviousItem1.Name = "BindingNavigatorMovePreviousItem1"
        '
        'BindingNavigatorSeparator3
        '
        Me.BindingNavigatorSeparator3.Name = "BindingNavigatorSeparator3"
        resources.ApplyResources(Me.BindingNavigatorSeparator3, "BindingNavigatorSeparator3")
        '
        'BindingNavigatorPositionItem1
        '
        resources.ApplyResources(Me.BindingNavigatorPositionItem1, "BindingNavigatorPositionItem1")
        Me.BindingNavigatorPositionItem1.Name = "BindingNavigatorPositionItem1"
        '
        'BindingNavigatorSeparator4
        '
        Me.BindingNavigatorSeparator4.Name = "BindingNavigatorSeparator4"
        resources.ApplyResources(Me.BindingNavigatorSeparator4, "BindingNavigatorSeparator4")
        '
        'BindingNavigatorMoveNextItem1
        '
        Me.BindingNavigatorMoveNextItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMoveNextItem1, "BindingNavigatorMoveNextItem1")
        Me.BindingNavigatorMoveNextItem1.Name = "BindingNavigatorMoveNextItem1"
        '
        'BindingNavigatorMoveLastItem1
        '
        Me.BindingNavigatorMoveLastItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMoveLastItem1, "BindingNavigatorMoveLastItem1")
        Me.BindingNavigatorMoveLastItem1.Name = "BindingNavigatorMoveLastItem1"
        '
        'BindingNavigatorSeparator5
        '
        Me.BindingNavigatorSeparator5.Name = "BindingNavigatorSeparator5"
        resources.ApplyResources(Me.BindingNavigatorSeparator5, "BindingNavigatorSeparator5")
        '
        'Phone__TextBox1
        '
        Me.Phone__TextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StaffBindingSource, "Phone #", True))
        resources.ApplyResources(Me.Phone__TextBox1, "Phone__TextBox1")
        Me.Phone__TextBox1.Name = "Phone__TextBox1"
        Me.Phone__TextBox1.ReadOnly = True
        '
        'PositionTextBox
        '
        Me.PositionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StaffBindingSource, "Position", True))
        resources.ApplyResources(Me.PositionTextBox, "PositionTextBox")
        Me.PositionTextBox.Name = "PositionTextBox"
        Me.PositionTextBox.ReadOnly = True
        '
        'StaffIDTextBox
        '
        Me.StaffIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StaffBindingSource, "StaffID", True))
        resources.ApplyResources(Me.StaffIDTextBox, "StaffIDTextBox")
        Me.StaffIDTextBox.Name = "StaffIDTextBox"
        Me.StaffIDTextBox.ReadOnly = True
        '
        'NameComboBox
        '
        Me.NameComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StaffBindingSource, "Name", True))
        Me.NameComboBox.DataSource = Me.StaffBindingSource
        Me.NameComboBox.DisplayMember = "Name"
        Me.NameComboBox.FormattingEnabled = True
        resources.ApplyResources(Me.NameComboBox, "NameComboBox")
        Me.NameComboBox.Name = "NameComboBox"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.MonthRbtn)
        Me.GroupBox1.Controls.Add(Me.WeekRbtn)
        Me.GroupBox1.Controls.Add(Me.DayRbtn)
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        '
        'MonthRbtn
        '
        resources.ApplyResources(Me.MonthRbtn, "MonthRbtn")
        Me.MonthRbtn.Name = "MonthRbtn"
        Me.MonthRbtn.TabStop = True
        Me.MonthRbtn.UseVisualStyleBackColor = True
        '
        'WeekRbtn
        '
        resources.ApplyResources(Me.WeekRbtn, "WeekRbtn")
        Me.WeekRbtn.Name = "WeekRbtn"
        Me.WeekRbtn.TabStop = True
        Me.WeekRbtn.UseVisualStyleBackColor = True
        '
        'DayRbtn
        '
        resources.ApplyResources(Me.DayRbtn, "DayRbtn")
        Me.DayRbtn.Name = "DayRbtn"
        Me.DayRbtn.TabStop = True
        Me.DayRbtn.UseVisualStyleBackColor = True
        '
        'StaffScheduleGrid
        '
        Me.StaffScheduleGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        resources.ApplyResources(Me.StaffScheduleGrid, "StaffScheduleGrid")
        Me.StaffScheduleGrid.Name = "StaffScheduleGrid"
        Me.StaffScheduleGrid.ReadOnly = True
        '
        'tabAddClass
        '
        Me.tabAddClass.Controls.Add(Me.btnOK)
        Me.tabAddClass.Controls.Add(Me.ClassTime)
        Me.tabAddClass.Controls.Add(Me.ClassDate)
        Me.tabAddClass.Controls.Add(Me.Instructors)
        Me.tabAddClass.Controls.Add(Me.Label2)
        resources.ApplyResources(Me.tabAddClass, "tabAddClass")
        Me.tabAddClass.Name = "tabAddClass"
        Me.tabAddClass.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        resources.ApplyResources(Me.btnOK, "btnOK")
        Me.btnOK.Name = "btnOK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'ClassTime
        '
        Me.ClassTime.FormattingEnabled = True
        resources.ApplyResources(Me.ClassTime, "ClassTime")
        Me.ClassTime.Name = "ClassTime"
        '
        'ClassDate
        '
        resources.ApplyResources(Me.ClassDate, "ClassDate")
        Me.ClassDate.Name = "ClassDate"
        '
        'Instructors
        '
        Me.Instructors.DataSource = Me.CPSC_285_5DataSet
        Me.Instructors.DisplayMember = "Instructors.Name"
        Me.Instructors.FormattingEnabled = True
        resources.ApplyResources(Me.Instructors, "Instructors")
        Me.Instructors.Name = "Instructors"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'ClientTableAdapter
        '
        Me.ClientTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ClassesTableAdapter = Nothing
        Me.TableAdapterManager.ClientTableAdapter = Me.ClientTableAdapter
        Me.TableAdapterManager.ExtraTableAdapter = Nothing
        Me.TableAdapterManager.StaffTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = A11_Group5.CPSC_285_5DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'StaffTableAdapter
        '
        Me.StaffTableAdapter.ClearBeforeFill = True
        '
        'ClassesTableAdapter
        '
        Me.ClassesTableAdapter.ClearBeforeFill = True
        '
        'InstructorsBindingSource
        '
        Me.InstructorsBindingSource.DataMember = "Instructors"
        Me.InstructorsBindingSource.DataSource = Me.CPSC_285_5DataSet
        '
        'InstructorsTableAdapter
        '
        Me.InstructorsTableAdapter.ClearBeforeFill = True
        '
        'driveSchoolForm
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SchoolTabControl)
        Me.Name = "driveSchoolForm"
        Me.ToolStripContainer1.BottomToolStripPanel.ResumeLayout(False)
        Me.ToolStripContainer1.BottomToolStripPanel.PerformLayout()
        Me.ToolStripContainer1.ResumeLayout(False)
        Me.ToolStripContainer1.PerformLayout()
        CType(Me.ClientBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ClientBindingNavigator.ResumeLayout(False)
        Me.ClientBindingNavigator.PerformLayout()
        CType(Me.ClientBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CPSC_285_5DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SchoolTabControl.ResumeLayout(False)
        Me.tabClientNav.ResumeLayout(False)
        Me.tabClientNav.PerformLayout()
        CType(Me.gridSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabRegistration.ResumeLayout(False)
        Me.tabRegistration.PerformLayout()
        Me.tabStaff.ResumeLayout(False)
        Me.tabStaff.PerformLayout()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BindingNavigator1.ResumeLayout(False)
        Me.BindingNavigator1.PerformLayout()
        CType(Me.StaffBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.StaffScheduleGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabAddClass.ResumeLayout(False)
        Me.tabAddClass.PerformLayout()
        CType(Me.InstructorsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents SchoolTabControl As TabControl
    Friend WithEvents tabClientNav As TabPage
    Friend WithEvents tabRegistration As TabPage
    Friend WithEvents tabStaff As TabPage
    Friend WithEvents tabAddClass As TabPage
    Friend WithEvents RTitle As Label
    Friend WithEvents RTelNumLbl As Label
    Friend WithEvents RDobLbl As Label
    Friend WithEvents RLastNmLb As Label
    Friend WithEvents RFirstNmLb As Label
    Friend WithEvents RRegisterBtn As Button
    Friend WithEvents RMaritalStatLbl As Label
    Friend WithEvents RSingleRadioBtn As RadioButton
    Friend WithEvents RMarryRadioBtn As RadioButton
    Friend WithEvents rPhoneNumTxtBx As TextBox
    Friend WithEvents rDobTxtBx As TextBox
    Friend WithEvents rLNameTxtBx As TextBox
    Friend WithEvents rFNameTxtBx As TextBox
    Friend WithEvents lblClients As Label
    Friend WithEvents CPSC_285_5DataSet As CPSC_285_5DataSet
    Friend WithEvents ClientBindingSource As BindingSource
    Friend WithEvents ClientTableAdapter As CPSC_285_5DataSetTableAdapters.ClientTableAdapter
    Friend WithEvents TableAdapterManager As CPSC_285_5DataSetTableAdapters.TableAdapterManager
    Friend WithEvents ClientBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents ClientBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents ClientIDTextBox As TextBox
    Friend WithEvents NameTextBox As TextBox
    Friend WithEvents Date_of_BirthDateTimePicker As DateTimePicker
    Friend WithEvents Phone__TextBox As TextBox
    Friend WithEvents chkMarried As CheckBox
    Friend WithEvents gridSchedule As DataGridView
    Friend WithEvents StaffBindingSource As BindingSource
    Friend WithEvents StaffTableAdapter As CPSC_285_5DataSetTableAdapters.StaffTableAdapter
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents MonthRbtn As RadioButton
    Friend WithEvents WeekRbtn As RadioButton
    Friend WithEvents DayRbtn As RadioButton
    Friend WithEvents StaffScheduleGrid As DataGridView
    Friend WithEvents ToolStripContainer1 As ToolStripContainer
    Friend WithEvents Phone__TextBox1 As TextBox
    Friend WithEvents PositionTextBox As TextBox
    Friend WithEvents StaffIDTextBox As TextBox
    Friend WithEvents NameComboBox As ComboBox
    Friend WithEvents BindingNavigator1 As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem1 As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator3 As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem1 As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator4 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator5 As ToolStripSeparator
    Friend WithEvents btnOK As Button
    Friend WithEvents ClassTime As ComboBox
    Friend WithEvents ClassDate As DateTimePicker
    Friend WithEvents Instructors As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents ClassesTableAdapter As A11_Group5.CPSC_285_5DataSetTableAdapters.ClassesTableAdapter
    Friend WithEvents InstructorsBindingSource As BindingSource
    Friend WithEvents InstructorsTableAdapter As CPSC_285_5DataSetTableAdapters.InstructorsTableAdapter
End Class
