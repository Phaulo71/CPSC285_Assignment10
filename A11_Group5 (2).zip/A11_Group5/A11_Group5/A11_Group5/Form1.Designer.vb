﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class driveSchoolForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ClientIDLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(driveSchoolForm))
        Dim NameLabel As System.Windows.Forms.Label
        Dim Marital_StatusLabel As System.Windows.Forms.Label
        Dim Date_of_BirthLabel As System.Windows.Forms.Label
        Dim Phone__Label As System.Windows.Forms.Label
        Dim NameLabel1 As System.Windows.Forms.Label
        Dim StaffIDLabel As System.Windows.Forms.Label
        Dim PositionLabel As System.Windows.Forms.Label
        Dim Phone__Label1 As System.Windows.Forms.Label
        Me.ToolStripContainer1 = New System.Windows.Forms.ToolStripContainer()
        Me.ClientBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.ClientBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CPSC_285_5DataSet = New A11_Group5.CPSC_285_5DataSet()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ClientBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.SchoolTabControl = New System.Windows.Forms.TabControl()
        Me.pgClientView = New System.Windows.Forms.TabPage()
        Me.gridSchedule = New System.Windows.Forms.DataGridView()
        Me.chkMarried = New System.Windows.Forms.CheckBox()
        Me.ClientIDTextBox = New System.Windows.Forms.TextBox()
        Me.NameTextBox = New System.Windows.Forms.TextBox()
        Me.Date_of_BirthDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Phone__TextBox = New System.Windows.Forms.TextBox()
        Me.lblClients = New System.Windows.Forms.Label()
        Me.registerTab = New System.Windows.Forms.TabPage()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.RRegisterBtn = New System.Windows.Forms.Button()
        Me.RMaritalStatLbl = New System.Windows.Forms.Label()
        Me.RSingleRadioBtn = New System.Windows.Forms.RadioButton()
        Me.RMarryRadioBtn = New System.Windows.Forms.RadioButton()
        Me.RTitle = New System.Windows.Forms.Label()
        Me.RTelNumLbl = New System.Windows.Forms.Label()
        Me.RDobLbl = New System.Windows.Forms.Label()
        Me.RLastNmLb = New System.Windows.Forms.Label()
        Me.RFirstNmLb = New System.Windows.Forms.Label()
        Me.StaffTab = New System.Windows.Forms.TabPage()
        Me.BindingNavigator1 = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem1 = New System.Windows.Forms.ToolStripButton()
        Me.StaffBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BindingNavigatorCountItem1 = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem1 = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.Phone__TextBox1 = New System.Windows.Forms.TextBox()
        Me.PositionTextBox = New System.Windows.Forms.TextBox()
        Me.StaffIDTextBox = New System.Windows.Forms.TextBox()
        Me.NameComboBox = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.MonthRbtn = New System.Windows.Forms.RadioButton()
        Me.WeekRbtn = New System.Windows.Forms.RadioButton()
        Me.DayRbtn = New System.Windows.Forms.RadioButton()
        Me.StaffScheduleGrid = New System.Windows.Forms.DataGridView()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.ClientTableAdapter = New A11_Group5.CPSC_285_5DataSetTableAdapters.ClientTableAdapter()
        Me.TableAdapterManager = New A11_Group5.CPSC_285_5DataSetTableAdapters.TableAdapterManager()
        Me.StaffTableAdapter = New A11_Group5.CPSC_285_5DataSetTableAdapters.StaffTableAdapter()
        ClientIDLabel = New System.Windows.Forms.Label()
        NameLabel = New System.Windows.Forms.Label()
        Marital_StatusLabel = New System.Windows.Forms.Label()
        Date_of_BirthLabel = New System.Windows.Forms.Label()
        Phone__Label = New System.Windows.Forms.Label()
        NameLabel1 = New System.Windows.Forms.Label()
        StaffIDLabel = New System.Windows.Forms.Label()
        PositionLabel = New System.Windows.Forms.Label()
        Phone__Label1 = New System.Windows.Forms.Label()
        Me.ToolStripContainer1.BottomToolStripPanel.SuspendLayout()
        Me.ToolStripContainer1.SuspendLayout()
        CType(Me.ClientBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ClientBindingNavigator.SuspendLayout()
        CType(Me.ClientBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CPSC_285_5DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SchoolTabControl.SuspendLayout()
        Me.pgClientView.SuspendLayout()
        CType(Me.gridSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.registerTab.SuspendLayout()
        Me.StaffTab.SuspendLayout()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BindingNavigator1.SuspendLayout()
        CType(Me.StaffBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.StaffScheduleGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ClientIDLabel
        '
        resources.ApplyResources(ClientIDLabel, "ClientIDLabel")
        ClientIDLabel.Name = "ClientIDLabel"
        '
        'ToolStripContainer1
        '
        '
        'ToolStripContainer1.BottomToolStripPanel
        '
        Me.ToolStripContainer1.BottomToolStripPanel.Controls.Add(Me.ClientBindingNavigator)
        '
        'ToolStripContainer1.ContentPanel
        '
        resources.ApplyResources(Me.ToolStripContainer1.ContentPanel, "ToolStripContainer1.ContentPanel")
        resources.ApplyResources(Me.ToolStripContainer1, "ToolStripContainer1")
        Me.ToolStripContainer1.Name = "ToolStripContainer1"
        '
        'ClientBindingNavigator
        '
        Me.ClientBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.ClientBindingNavigator.BindingSource = Me.ClientBindingSource
        Me.ClientBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.ClientBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        resources.ApplyResources(Me.ClientBindingNavigator, "ClientBindingNavigator")
        Me.ClientBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.ClientBindingNavigatorSaveItem})
        Me.ClientBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.ClientBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.ClientBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.ClientBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.ClientBindingNavigator.Name = "ClientBindingNavigator"
        Me.ClientBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorAddNewItem, "BindingNavigatorAddNewItem")
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        '
        'ClientBindingSource
        '
        Me.ClientBindingSource.DataMember = "Client"
        Me.ClientBindingSource.DataSource = Me.CPSC_285_5DataSet
        '
        'CPSC_285_5DataSet
        '
        Me.CPSC_285_5DataSet.DataSetName = "CPSC_285_5DataSet"
        Me.CPSC_285_5DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        resources.ApplyResources(Me.BindingNavigatorCountItem, "BindingNavigatorCountItem")
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorDeleteItem, "BindingNavigatorDeleteItem")
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMoveFirstItem, "BindingNavigatorMoveFirstItem")
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMovePreviousItem, "BindingNavigatorMovePreviousItem")
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        resources.ApplyResources(Me.BindingNavigatorSeparator, "BindingNavigatorSeparator")
        '
        'BindingNavigatorPositionItem
        '
        resources.ApplyResources(Me.BindingNavigatorPositionItem, "BindingNavigatorPositionItem")
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        resources.ApplyResources(Me.BindingNavigatorSeparator1, "BindingNavigatorSeparator1")
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMoveNextItem, "BindingNavigatorMoveNextItem")
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMoveLastItem, "BindingNavigatorMoveLastItem")
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        resources.ApplyResources(Me.BindingNavigatorSeparator2, "BindingNavigatorSeparator2")
        '
        'ClientBindingNavigatorSaveItem
        '
        Me.ClientBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.ClientBindingNavigatorSaveItem, "ClientBindingNavigatorSaveItem")
        Me.ClientBindingNavigatorSaveItem.Name = "ClientBindingNavigatorSaveItem"
        '
        'NameLabel
        '
        resources.ApplyResources(NameLabel, "NameLabel")
        NameLabel.Name = "NameLabel"
        '
        'Marital_StatusLabel
        '
        resources.ApplyResources(Marital_StatusLabel, "Marital_StatusLabel")
        Marital_StatusLabel.Name = "Marital_StatusLabel"
        '
        'Date_of_BirthLabel
        '
        resources.ApplyResources(Date_of_BirthLabel, "Date_of_BirthLabel")
        Date_of_BirthLabel.Name = "Date_of_BirthLabel"
        '
        'Phone__Label
        '
        resources.ApplyResources(Phone__Label, "Phone__Label")
        Phone__Label.Name = "Phone__Label"
        '
        'NameLabel1
        '
        resources.ApplyResources(NameLabel1, "NameLabel1")
        NameLabel1.Name = "NameLabel1"
        '
        'StaffIDLabel
        '
        resources.ApplyResources(StaffIDLabel, "StaffIDLabel")
        StaffIDLabel.Name = "StaffIDLabel"
        '
        'PositionLabel
        '
        resources.ApplyResources(PositionLabel, "PositionLabel")
        PositionLabel.Name = "PositionLabel"
        '
        'Phone__Label1
        '
        resources.ApplyResources(Phone__Label1, "Phone__Label1")
        Phone__Label1.Name = "Phone__Label1"
        '
        'SchoolTabControl
        '
        Me.SchoolTabControl.Controls.Add(Me.pgClientView)
        Me.SchoolTabControl.Controls.Add(Me.registerTab)
        Me.SchoolTabControl.Controls.Add(Me.StaffTab)
        Me.SchoolTabControl.Controls.Add(Me.TabPage4)
        resources.ApplyResources(Me.SchoolTabControl, "SchoolTabControl")
        Me.SchoolTabControl.Name = "SchoolTabControl"
        Me.SchoolTabControl.SelectedIndex = 0
        '
        'pgClientView
        '
        Me.pgClientView.Controls.Add(Me.gridSchedule)
        Me.pgClientView.Controls.Add(Me.ToolStripContainer1)
        Me.pgClientView.Controls.Add(Me.chkMarried)
        Me.pgClientView.Controls.Add(ClientIDLabel)
        Me.pgClientView.Controls.Add(Me.ClientIDTextBox)
        Me.pgClientView.Controls.Add(NameLabel)
        Me.pgClientView.Controls.Add(Me.NameTextBox)
        Me.pgClientView.Controls.Add(Marital_StatusLabel)
        Me.pgClientView.Controls.Add(Date_of_BirthLabel)
        Me.pgClientView.Controls.Add(Me.Date_of_BirthDateTimePicker)
        Me.pgClientView.Controls.Add(Phone__Label)
        Me.pgClientView.Controls.Add(Me.Phone__TextBox)
        Me.pgClientView.Controls.Add(Me.lblClients)
        resources.ApplyResources(Me.pgClientView, "pgClientView")
        Me.pgClientView.Name = "pgClientView"
        Me.pgClientView.UseVisualStyleBackColor = True
        '
        'gridSchedule
        '
        Me.gridSchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        resources.ApplyResources(Me.gridSchedule, "gridSchedule")
        Me.gridSchedule.Name = "gridSchedule"
        '
        'chkMarried
        '
        resources.ApplyResources(Me.chkMarried, "chkMarried")
        Me.chkMarried.Checked = True
        Me.chkMarried.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkMarried.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.ClientBindingSource, "Marital Status", True))
        Me.chkMarried.Name = "chkMarried"
        Me.chkMarried.UseVisualStyleBackColor = True
        '
        'ClientIDTextBox
        '
        Me.ClientIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClientBindingSource, "ClientID", True))
        resources.ApplyResources(Me.ClientIDTextBox, "ClientIDTextBox")
        Me.ClientIDTextBox.Name = "ClientIDTextBox"
        Me.ClientIDTextBox.ReadOnly = True
        '
        'NameTextBox
        '
        Me.NameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClientBindingSource, "Name", True))
        resources.ApplyResources(Me.NameTextBox, "NameTextBox")
        Me.NameTextBox.Name = "NameTextBox"
        Me.NameTextBox.ReadOnly = True
        '
        'Date_of_BirthDateTimePicker
        '
        Me.Date_of_BirthDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.ClientBindingSource, "Date of Birth", True))
        resources.ApplyResources(Me.Date_of_BirthDateTimePicker, "Date_of_BirthDateTimePicker")
        Me.Date_of_BirthDateTimePicker.Name = "Date_of_BirthDateTimePicker"
        '
        'Phone__TextBox
        '
        Me.Phone__TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClientBindingSource, "Phone #", True))
        resources.ApplyResources(Me.Phone__TextBox, "Phone__TextBox")
        Me.Phone__TextBox.Name = "Phone__TextBox"
        Me.Phone__TextBox.ReadOnly = True
        '
        'lblClients
        '
        resources.ApplyResources(Me.lblClients, "lblClients")
        Me.lblClients.Name = "lblClients"
        '
        'registerTab
        '
        Me.registerTab.Controls.Add(Me.TextBox4)
        Me.registerTab.Controls.Add(Me.TextBox3)
        Me.registerTab.Controls.Add(Me.TextBox2)
        Me.registerTab.Controls.Add(Me.TextBox1)
        Me.registerTab.Controls.Add(Me.RRegisterBtn)
        Me.registerTab.Controls.Add(Me.RMaritalStatLbl)
        Me.registerTab.Controls.Add(Me.RSingleRadioBtn)
        Me.registerTab.Controls.Add(Me.RMarryRadioBtn)
        Me.registerTab.Controls.Add(Me.RTitle)
        Me.registerTab.Controls.Add(Me.RTelNumLbl)
        Me.registerTab.Controls.Add(Me.RDobLbl)
        Me.registerTab.Controls.Add(Me.RLastNmLb)
        Me.registerTab.Controls.Add(Me.RFirstNmLb)
        resources.ApplyResources(Me.registerTab, "registerTab")
        Me.registerTab.Name = "registerTab"
        Me.registerTab.UseVisualStyleBackColor = True
        '
        'TextBox4
        '
        resources.ApplyResources(Me.TextBox4, "TextBox4")
        Me.TextBox4.Name = "TextBox4"
        '
        'TextBox3
        '
        resources.ApplyResources(Me.TextBox3, "TextBox3")
        Me.TextBox3.Name = "TextBox3"
        '
        'TextBox2
        '
        resources.ApplyResources(Me.TextBox2, "TextBox2")
        Me.TextBox2.Name = "TextBox2"
        '
        'TextBox1
        '
        resources.ApplyResources(Me.TextBox1, "TextBox1")
        Me.TextBox1.Name = "TextBox1"
        '
        'RRegisterBtn
        '
        resources.ApplyResources(Me.RRegisterBtn, "RRegisterBtn")
        Me.RRegisterBtn.Name = "RRegisterBtn"
        Me.RRegisterBtn.UseVisualStyleBackColor = True
        '
        'RMaritalStatLbl
        '
        resources.ApplyResources(Me.RMaritalStatLbl, "RMaritalStatLbl")
        Me.RMaritalStatLbl.Name = "RMaritalStatLbl"
        '
        'RSingleRadioBtn
        '
        resources.ApplyResources(Me.RSingleRadioBtn, "RSingleRadioBtn")
        Me.RSingleRadioBtn.Name = "RSingleRadioBtn"
        Me.RSingleRadioBtn.UseVisualStyleBackColor = True
        '
        'RMarryRadioBtn
        '
        resources.ApplyResources(Me.RMarryRadioBtn, "RMarryRadioBtn")
        Me.RMarryRadioBtn.Checked = True
        Me.RMarryRadioBtn.Name = "RMarryRadioBtn"
        Me.RMarryRadioBtn.TabStop = True
        Me.RMarryRadioBtn.UseVisualStyleBackColor = True
        '
        'RTitle
        '
        resources.ApplyResources(Me.RTitle, "RTitle")
        Me.RTitle.Name = "RTitle"
        '
        'RTelNumLbl
        '
        resources.ApplyResources(Me.RTelNumLbl, "RTelNumLbl")
        Me.RTelNumLbl.Name = "RTelNumLbl"
        '
        'RDobLbl
        '
        resources.ApplyResources(Me.RDobLbl, "RDobLbl")
        Me.RDobLbl.Name = "RDobLbl"
        '
        'RLastNmLb
        '
        resources.ApplyResources(Me.RLastNmLb, "RLastNmLb")
        Me.RLastNmLb.Name = "RLastNmLb"
        '
        'RFirstNmLb
        '
        resources.ApplyResources(Me.RFirstNmLb, "RFirstNmLb")
        Me.RFirstNmLb.Name = "RFirstNmLb"
        '
        'StaffTab
        '
        resources.ApplyResources(Me.StaffTab, "StaffTab")
        Me.StaffTab.Controls.Add(Me.BindingNavigator1)
        Me.StaffTab.Controls.Add(Phone__Label1)
        Me.StaffTab.Controls.Add(Me.Phone__TextBox1)
        Me.StaffTab.Controls.Add(PositionLabel)
        Me.StaffTab.Controls.Add(Me.PositionTextBox)
        Me.StaffTab.Controls.Add(StaffIDLabel)
        Me.StaffTab.Controls.Add(Me.StaffIDTextBox)
        Me.StaffTab.Controls.Add(NameLabel1)
        Me.StaffTab.Controls.Add(Me.NameComboBox)
        Me.StaffTab.Controls.Add(Me.Label1)
        Me.StaffTab.Controls.Add(Me.GroupBox1)
        Me.StaffTab.Controls.Add(Me.StaffScheduleGrid)
        Me.StaffTab.Name = "StaffTab"
        Me.StaffTab.UseVisualStyleBackColor = True
        '
        'BindingNavigator1
        '
        Me.BindingNavigator1.AddNewItem = Me.BindingNavigatorAddNewItem1
        Me.BindingNavigator1.BindingSource = Me.StaffBindingSource
        Me.BindingNavigator1.CountItem = Me.BindingNavigatorCountItem1
        Me.BindingNavigator1.DeleteItem = Me.BindingNavigatorDeleteItem1
        Me.BindingNavigator1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem1, Me.BindingNavigatorMovePreviousItem1, Me.BindingNavigatorSeparator3, Me.BindingNavigatorPositionItem1, Me.BindingNavigatorCountItem1, Me.BindingNavigatorSeparator4, Me.BindingNavigatorMoveNextItem1, Me.BindingNavigatorMoveLastItem1, Me.BindingNavigatorSeparator5, Me.BindingNavigatorAddNewItem1, Me.BindingNavigatorDeleteItem1})
        resources.ApplyResources(Me.BindingNavigator1, "BindingNavigator1")
        Me.BindingNavigator1.MoveFirstItem = Me.BindingNavigatorMoveFirstItem1
        Me.BindingNavigator1.MoveLastItem = Me.BindingNavigatorMoveLastItem1
        Me.BindingNavigator1.MoveNextItem = Me.BindingNavigatorMoveNextItem1
        Me.BindingNavigator1.MovePreviousItem = Me.BindingNavigatorMovePreviousItem1
        Me.BindingNavigator1.Name = "BindingNavigator1"
        Me.BindingNavigator1.PositionItem = Me.BindingNavigatorPositionItem1
        '
        'BindingNavigatorAddNewItem1
        '
        Me.BindingNavigatorAddNewItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorAddNewItem1, "BindingNavigatorAddNewItem1")
        Me.BindingNavigatorAddNewItem1.Name = "BindingNavigatorAddNewItem1"
        '
        'StaffBindingSource
        '
        Me.StaffBindingSource.DataMember = "Staff"
        Me.StaffBindingSource.DataSource = Me.CPSC_285_5DataSet
        '
        'BindingNavigatorCountItem1
        '
        Me.BindingNavigatorCountItem1.Name = "BindingNavigatorCountItem1"
        resources.ApplyResources(Me.BindingNavigatorCountItem1, "BindingNavigatorCountItem1")
        '
        'BindingNavigatorDeleteItem1
        '
        Me.BindingNavigatorDeleteItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorDeleteItem1, "BindingNavigatorDeleteItem1")
        Me.BindingNavigatorDeleteItem1.Name = "BindingNavigatorDeleteItem1"
        '
        'BindingNavigatorMoveFirstItem1
        '
        Me.BindingNavigatorMoveFirstItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMoveFirstItem1, "BindingNavigatorMoveFirstItem1")
        Me.BindingNavigatorMoveFirstItem1.Name = "BindingNavigatorMoveFirstItem1"
        '
        'BindingNavigatorMovePreviousItem1
        '
        Me.BindingNavigatorMovePreviousItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMovePreviousItem1, "BindingNavigatorMovePreviousItem1")
        Me.BindingNavigatorMovePreviousItem1.Name = "BindingNavigatorMovePreviousItem1"
        '
        'BindingNavigatorSeparator3
        '
        Me.BindingNavigatorSeparator3.Name = "BindingNavigatorSeparator3"
        resources.ApplyResources(Me.BindingNavigatorSeparator3, "BindingNavigatorSeparator3")
        '
        'BindingNavigatorPositionItem1
        '
        resources.ApplyResources(Me.BindingNavigatorPositionItem1, "BindingNavigatorPositionItem1")
        Me.BindingNavigatorPositionItem1.Name = "BindingNavigatorPositionItem1"
        '
        'BindingNavigatorSeparator4
        '
        Me.BindingNavigatorSeparator4.Name = "BindingNavigatorSeparator4"
        resources.ApplyResources(Me.BindingNavigatorSeparator4, "BindingNavigatorSeparator4")
        '
        'BindingNavigatorMoveNextItem1
        '
        Me.BindingNavigatorMoveNextItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMoveNextItem1, "BindingNavigatorMoveNextItem1")
        Me.BindingNavigatorMoveNextItem1.Name = "BindingNavigatorMoveNextItem1"
        '
        'BindingNavigatorMoveLastItem1
        '
        Me.BindingNavigatorMoveLastItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        resources.ApplyResources(Me.BindingNavigatorMoveLastItem1, "BindingNavigatorMoveLastItem1")
        Me.BindingNavigatorMoveLastItem1.Name = "BindingNavigatorMoveLastItem1"
        '
        'BindingNavigatorSeparator5
        '
        Me.BindingNavigatorSeparator5.Name = "BindingNavigatorSeparator5"
        resources.ApplyResources(Me.BindingNavigatorSeparator5, "BindingNavigatorSeparator5")
        '
        'Phone__TextBox1
        '
        Me.Phone__TextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StaffBindingSource, "Phone #", True))
        resources.ApplyResources(Me.Phone__TextBox1, "Phone__TextBox1")
        Me.Phone__TextBox1.Name = "Phone__TextBox1"
        '
        'PositionTextBox
        '
        Me.PositionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StaffBindingSource, "Position", True))
        resources.ApplyResources(Me.PositionTextBox, "PositionTextBox")
        Me.PositionTextBox.Name = "PositionTextBox"
        '
        'StaffIDTextBox
        '
        Me.StaffIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StaffBindingSource, "StaffID", True))
        resources.ApplyResources(Me.StaffIDTextBox, "StaffIDTextBox")
        Me.StaffIDTextBox.Name = "StaffIDTextBox"
        '
        'NameComboBox
        '
        Me.NameComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StaffBindingSource, "Name", True))
        Me.NameComboBox.DataSource = Me.StaffBindingSource
        Me.NameComboBox.DisplayMember = "Name"
        Me.NameComboBox.FormattingEnabled = True
        resources.ApplyResources(Me.NameComboBox, "NameComboBox")
        Me.NameComboBox.Name = "NameComboBox"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.MonthRbtn)
        Me.GroupBox1.Controls.Add(Me.WeekRbtn)
        Me.GroupBox1.Controls.Add(Me.DayRbtn)
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        '
        'MonthRbtn
        '
        resources.ApplyResources(Me.MonthRbtn, "MonthRbtn")
        Me.MonthRbtn.Name = "MonthRbtn"
        Me.MonthRbtn.TabStop = True
        Me.MonthRbtn.UseVisualStyleBackColor = True
        '
        'WeekRbtn
        '
        resources.ApplyResources(Me.WeekRbtn, "WeekRbtn")
        Me.WeekRbtn.Name = "WeekRbtn"
        Me.WeekRbtn.TabStop = True
        Me.WeekRbtn.UseVisualStyleBackColor = True
        '
        'DayRbtn
        '
        resources.ApplyResources(Me.DayRbtn, "DayRbtn")
        Me.DayRbtn.Name = "DayRbtn"
        Me.DayRbtn.TabStop = True
        Me.DayRbtn.UseVisualStyleBackColor = True
        '
        'StaffScheduleGrid
        '
        Me.StaffScheduleGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        resources.ApplyResources(Me.StaffScheduleGrid, "StaffScheduleGrid")
        Me.StaffScheduleGrid.Name = "StaffScheduleGrid"
        '
        'TabPage4
        '
        resources.ApplyResources(Me.TabPage4, "TabPage4")
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'ClientTableAdapter
        '
        Me.ClientTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ClassesTableAdapter = Nothing
        Me.TableAdapterManager.ClientTableAdapter = Me.ClientTableAdapter
        Me.TableAdapterManager.ExtraTableAdapter = Nothing
        Me.TableAdapterManager.StaffTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = A11_Group5.CPSC_285_5DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'StaffTableAdapter
        '
        Me.StaffTableAdapter.ClearBeforeFill = True
        '
        'driveSchoolForm
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SchoolTabControl)
        Me.Name = "driveSchoolForm"
        Me.ToolStripContainer1.BottomToolStripPanel.ResumeLayout(False)
        Me.ToolStripContainer1.BottomToolStripPanel.PerformLayout()
        Me.ToolStripContainer1.ResumeLayout(False)
        Me.ToolStripContainer1.PerformLayout()
        CType(Me.ClientBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ClientBindingNavigator.ResumeLayout(False)
        Me.ClientBindingNavigator.PerformLayout()
        CType(Me.ClientBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CPSC_285_5DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SchoolTabControl.ResumeLayout(False)
        Me.pgClientView.ResumeLayout(False)
        Me.pgClientView.PerformLayout()
        CType(Me.gridSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        Me.registerTab.ResumeLayout(False)
        Me.registerTab.PerformLayout()
        Me.StaffTab.ResumeLayout(False)
        Me.StaffTab.PerformLayout()
        CType(Me.BindingNavigator1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BindingNavigator1.ResumeLayout(False)
        Me.BindingNavigator1.PerformLayout()
        CType(Me.StaffBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.StaffScheduleGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents SchoolTabControl As TabControl
    Friend WithEvents pgClientView As TabPage
    Friend WithEvents registerTab As TabPage
    Friend WithEvents StaffTab As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents RTitle As Label
    Friend WithEvents RTelNumLbl As Label
    Friend WithEvents RDobLbl As Label
    Friend WithEvents RLastNmLb As Label
    Friend WithEvents RFirstNmLb As Label
    Friend WithEvents RRegisterBtn As Button
    Friend WithEvents RMaritalStatLbl As Label
    Friend WithEvents RSingleRadioBtn As RadioButton
    Friend WithEvents RMarryRadioBtn As RadioButton
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents lblClients As Label
    Friend WithEvents CPSC_285_5DataSet As CPSC_285_5DataSet
    Friend WithEvents ClientBindingSource As BindingSource
    Friend WithEvents ClientTableAdapter As CPSC_285_5DataSetTableAdapters.ClientTableAdapter
    Friend WithEvents TableAdapterManager As CPSC_285_5DataSetTableAdapters.TableAdapterManager
    Friend WithEvents ClientBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents ClientBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents ClientIDTextBox As TextBox
    Friend WithEvents NameTextBox As TextBox
    Friend WithEvents Date_of_BirthDateTimePicker As DateTimePicker
    Friend WithEvents Phone__TextBox As TextBox
    Friend WithEvents chkMarried As CheckBox
    Friend WithEvents gridSchedule As DataGridView
    Friend WithEvents StaffBindingSource As BindingSource
    Friend WithEvents StaffTableAdapter As CPSC_285_5DataSetTableAdapters.StaffTableAdapter
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents MonthRbtn As RadioButton
    Friend WithEvents WeekRbtn As RadioButton
    Friend WithEvents DayRbtn As RadioButton
    Friend WithEvents StaffScheduleGrid As DataGridView
    Friend WithEvents ToolStripContainer1 As ToolStripContainer
    Friend WithEvents Phone__TextBox1 As TextBox
    Friend WithEvents PositionTextBox As TextBox
    Friend WithEvents StaffIDTextBox As TextBox
    Friend WithEvents NameComboBox As ComboBox
    Friend WithEvents BindingNavigator1 As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem1 As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator3 As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem1 As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator4 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem1 As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator5 As ToolStripSeparator
End Class
