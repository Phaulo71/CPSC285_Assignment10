﻿Partial Class CPSC_285_5DataSet
End Class

Namespace CPSC_285_5DataSetTableAdapters

    Partial Public Class StaffTableAdapter
    End Class
End Namespace
