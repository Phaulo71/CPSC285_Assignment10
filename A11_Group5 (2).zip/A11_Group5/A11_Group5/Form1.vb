﻿Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class driveSchoolForm
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CPSC_285_5DataSet.Staff' table. You can move, or remove it, as needed.
        Me.StaffTableAdapter.Fill(Me.CPSC_285_5DataSet.Staff)
        'TODO: This line of code loads data into the 'CPSC_285_5DataSet.Classes' table. You can move, or remove it, as needed.
        Me.ClassesTableAdapter.Fill(Me.CPSC_285_5DataSet.Classes)
        'TODO: This line of code loads data into the 'CPSC_285_5DataSet.Client' table. You can move, or remove it, as needed.
        Me.ClientTableAdapter.Fill(Me.CPSC_285_5DataSet.Client)
        instrQueryEnable.PerformClick()


        ' connectGridViewDate()
        ' connectGridViewTime()

    End Sub

    Private Sub TabResize(sender As Object, e As EventArgs) Handles MyBase.Resize
        SchoolTabControl.Size = Me.Size
    End Sub

    Private Sub MaritalStatusRB(sender As Object, e As EventArgs) Handles MyBase.Resize, RSingleRadioBtn.CheckedChanged, RMarryRadioBtn.CheckedChanged
        If (RMarryRadioBtn.Checked = True) Then
            RSingleRadioBtn.Checked = False
        ElseIf (RSingleRadioBtn.Checked = True) Then
            RMarryRadioBtn.Checked = False
        End If

    End Sub

    Private Sub ClientBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ClientBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ClientBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CPSC_285_5DataSet)

    End Sub

    Private Sub updateClasses()
        InitializeGridView()

        Dim stuID As Int32 = ClientIDTextBox.Text

        Dim cnnDriving As SqlConnection
        Dim strConnect As String = "Data Source=CISSQL;Initial Catalog=CPSC 285_5;Integrated Security=True"
        cnnDriving = New SqlConnection(strConnect)

        Dim cmdClientSchedule As SqlCommand
        Dim rdrSQL As SqlDataReader

        cnnDriving.Open()

        Dim strSql As String = "SELECT Classes.Date, Classes.Time, Staff.Name " &
                               "FROM Classes,Client,Staff " &
                                "WHERE Classes.ClientID = Client.ClientID " &
                                    "AND Classes.StaffID = Staff.StaffID " &
                                    "AND Client.ClientID = " & stuID

        cmdClientSchedule = New SqlCommand(strSql, cnnDriving)

        rdrSQL = cmdClientSchedule.ExecuteReader

        With rdrSQL
            If .HasRows Then
                Do While .Read
                    Dim cDay As DateTime = .Item(0)
                    Dim cTime As TimeSpan = .Item(1)

                    Dim row As String() = {cDay.ToString("d"), cTime.ToString("c"), .Item(2)}
                    gridSchedule.Rows.Add(row)
                Loop
            End If
        End With
    End Sub

    Private Sub InitializeGridView()
        gridSchedule.ColumnCount = 3
        gridSchedule.ColumnHeadersVisible = True

        Dim ColumnHeaderStyle As DataGridViewCellStyle = New DataGridViewCellStyle
        ColumnHeaderStyle.BackColor = Color.Beige
        ColumnHeaderStyle.Font = New Font("Verdana", 10, FontStyle.Bold)
        gridSchedule.ColumnHeadersDefaultCellStyle = ColumnHeaderStyle

        gridSchedule.Columns(0).Name = "Date"
        gridSchedule.Columns(1).Name = "Time"
        gridSchedule.Columns(2).Name = "Instructor"
    End Sub

    Private Sub ClientIDTextBox_TextChanged(sender As Object, e As EventArgs) Handles ClientIDTextBox.TextChanged
        gridSchedule.Rows.Clear()
        updateClasses()
    End Sub

    Private Sub InstructorsToolStripButton_Click(sender As Object, e As EventArgs) Handles instrQueryEnable.Click
        Try
            Me.StaffTableAdapter.Instructors(Me.CPSC_285_5DataSet.Staff)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub
    Private Sub addClassTime()

        Dim stuID As Int32 = ClientIDTextBox.Text

        Dim cnnDriving As SqlConnection
        Dim strConnect As String = "Data Source=CISSQL;Initial Catalog=CPSC 285_5;Integrated Security=True"
        cnnDriving = New SqlConnection(strConnect)

        Dim cmdClientSchedule As SqlCommand
        Dim rdrSQL As SqlDataReader

        cnnDriving.Open()

        Dim strSql As String = "SELECT TIME FROM CLASSES, STAFF, CLIENT WHERE CLASSES.STAFFID = STAFF.STAFFID AND CLASSES.CLIENTID = CLIENT.CLIENTID AND STAFF.NAME = '" & Instructors.SelectedText & "' AND CLASSES.DATE = " & ClassDate.Value
        cmdClientSchedule = New SqlCommand(strSql, cnnDriving)

        rdrSQL = cmdClientSchedule.ExecuteReader

        With rdrSQL
            If .HasRows Then
                Do While .Read
                    Dim cTime As TimeSpan = .Item(0)

                    ClassTime.Items.Add(cTime.ToString("c"))
                Loop
            End If
        End With
    End Sub
    Private Sub ClassDate_ValueChanged(sender As Object, e As EventArgs) Handles ClassDate.ValueChanged
        If ClassDate.Value.DayOfWeek = 0 Or ClassDate.Value.DayOfWeek = 6 Then
            MessageBox.Show("Classes are not held on weekends, please select a weekday")
            ClassDate.Value = "2017-4-27"
        End If
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Dim instructor As String = Instructors.SelectedText
        Dim time As String = ClassTime.SelectedValue
        Dim classDay As String = ClassDate.ToString()
        Dim clientID As Int32 = Integer.Parse(ClientIDTextBox.Text)

        If IsNothing(time) Then
            MessageBox.Show("Please Enter A Time")
        Else
            Dim cnnClass As SqlConnection
            Dim strConnect As String = "Data Source=CISSQL;Initial Catalog=CPSC 285_5;Integrated Security=True"
            cnnClass = New SqlConnection(strConnect)

            Dim cmdNewClass As SqlCommand
            Dim rdrSQL As SqlDataReader

            Dim strSQL As String = "UPDATE Classes" &
                                   " INNER JOIN STAFF on Classes.StaffID = Staff.StaffID" &
                                   " SET CLIENTID = '" & clientID & "'" &
                                   " WHERE DATE = '" & classDay & "'" &
                                   " AND Time = '" & time & "'" &
                                   " AND Name = '" & instructor & "'"



            Try
                cnnClass = New SqlConnection(strConnect)
                cnnClass.Open()

                cmdNewClass = New SqlCommand
                cmdNewClass.Connection = cnnClass
                cmdNewClass.CommandText = strSQL
                cmdNewClass.CommandType = CommandType.Text

                If (cmdNewClass.ExecuteNonQuery().Equals(1)) Then
                    MessageBox.Show("Class has been registered.")
                Else
                    MessageBox.Show("Could not register!")
                End If
                cnnClass.Close()
                Me.ClientTableAdapter.Fill(Me.CPSC_285_5DataSet.Client)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If


    End Sub
End Class

