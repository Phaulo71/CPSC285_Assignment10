﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class driveSchoolForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(driveSchoolForm))
        Me.SchoolTabControl = New System.Windows.Forms.TabControl()
        Me.TabPg = New System.Windows.Forms.TabPage()
        Me.registerTab = New System.Windows.Forms.TabPage()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.RRegisterBtn = New System.Windows.Forms.Button()
        Me.RMaritalStatLbl = New System.Windows.Forms.Label()
        Me.RSingleRadioBtn = New System.Windows.Forms.RadioButton()
        Me.RMarryRadioBtn = New System.Windows.Forms.RadioButton()
        Me.RTitle = New System.Windows.Forms.Label()
        Me.RTelNumLbl = New System.Windows.Forms.Label()
        Me.RDobLbl = New System.Windows.Forms.Label()
        Me.RLastNmLb = New System.Windows.Forms.Label()
        Me.RFirstNmLb = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.SchoolTabControl.SuspendLayout()
        Me.registerTab.SuspendLayout()
        Me.SuspendLayout()
        '
        'SchoolTabControl
        '
        Me.SchoolTabControl.Controls.Add(Me.TabPg)
        Me.SchoolTabControl.Controls.Add(Me.registerTab)
        Me.SchoolTabControl.Controls.Add(Me.TabPage3)
        Me.SchoolTabControl.Controls.Add(Me.TabPage4)
        resources.ApplyResources(Me.SchoolTabControl, "SchoolTabControl")
        Me.SchoolTabControl.Name = "SchoolTabControl"
        Me.SchoolTabControl.SelectedIndex = 0
        '
        'TabPg
        '
        resources.ApplyResources(Me.TabPg, "TabPg")
        Me.TabPg.Name = "TabPg"
        Me.TabPg.UseVisualStyleBackColor = True
        '
        'registerTab
        '
        Me.registerTab.Controls.Add(Me.TextBox4)
        Me.registerTab.Controls.Add(Me.TextBox3)
        Me.registerTab.Controls.Add(Me.TextBox2)
        Me.registerTab.Controls.Add(Me.TextBox1)
        Me.registerTab.Controls.Add(Me.RRegisterBtn)
        Me.registerTab.Controls.Add(Me.RMaritalStatLbl)
        Me.registerTab.Controls.Add(Me.RSingleRadioBtn)
        Me.registerTab.Controls.Add(Me.RMarryRadioBtn)
        Me.registerTab.Controls.Add(Me.RTitle)
        Me.registerTab.Controls.Add(Me.RTelNumLbl)
        Me.registerTab.Controls.Add(Me.RDobLbl)
        Me.registerTab.Controls.Add(Me.RLastNmLb)
        Me.registerTab.Controls.Add(Me.RFirstNmLb)
        resources.ApplyResources(Me.registerTab, "registerTab")
        Me.registerTab.Name = "registerTab"
        Me.registerTab.UseVisualStyleBackColor = True
        '
        'TextBox4
        '
        resources.ApplyResources(Me.TextBox4, "TextBox4")
        Me.TextBox4.Name = "TextBox4"
        '
        'TextBox3
        '
        resources.ApplyResources(Me.TextBox3, "TextBox3")
        Me.TextBox3.Name = "TextBox3"
        '
        'TextBox2
        '
        resources.ApplyResources(Me.TextBox2, "TextBox2")
        Me.TextBox2.Name = "TextBox2"
        '
        'TextBox1
        '
        resources.ApplyResources(Me.TextBox1, "TextBox1")
        Me.TextBox1.Name = "TextBox1"
        '
        'RRegisterBtn
        '
        resources.ApplyResources(Me.RRegisterBtn, "RRegisterBtn")
        Me.RRegisterBtn.Name = "RRegisterBtn"
        Me.RRegisterBtn.UseVisualStyleBackColor = True
        '
        'RMaritalStatLbl
        '
        resources.ApplyResources(Me.RMaritalStatLbl, "RMaritalStatLbl")
        Me.RMaritalStatLbl.Name = "RMaritalStatLbl"
        '
        'RSingleRadioBtn
        '
        resources.ApplyResources(Me.RSingleRadioBtn, "RSingleRadioBtn")
        Me.RSingleRadioBtn.Name = "RSingleRadioBtn"
        Me.RSingleRadioBtn.TabStop = True
        Me.RSingleRadioBtn.UseVisualStyleBackColor = True
        '
        'RMarryRadioBtn
        '
        resources.ApplyResources(Me.RMarryRadioBtn, "RMarryRadioBtn")
        Me.RMarryRadioBtn.Name = "RMarryRadioBtn"
        Me.RMarryRadioBtn.TabStop = True
        Me.RMarryRadioBtn.UseVisualStyleBackColor = True
        '
        'RTitle
        '
        resources.ApplyResources(Me.RTitle, "RTitle")
        Me.RTitle.Name = "RTitle"
        '
        'RTelNumLbl
        '
        resources.ApplyResources(Me.RTelNumLbl, "RTelNumLbl")
        Me.RTelNumLbl.Name = "RTelNumLbl"
        '
        'RDobLbl
        '
        resources.ApplyResources(Me.RDobLbl, "RDobLbl")
        Me.RDobLbl.Name = "RDobLbl"
        '
        'RLastNmLb
        '
        resources.ApplyResources(Me.RLastNmLb, "RLastNmLb")
        Me.RLastNmLb.Name = "RLastNmLb"
        '
        'RFirstNmLb
        '
        resources.ApplyResources(Me.RFirstNmLb, "RFirstNmLb")
        Me.RFirstNmLb.Name = "RFirstNmLb"
        '
        'TabPage3
        '
        resources.ApplyResources(Me.TabPage3, "TabPage3")
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        resources.ApplyResources(Me.TabPage4, "TabPage4")
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'driveSchoolForm
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SchoolTabControl)
        Me.Name = "driveSchoolForm"
        Me.SchoolTabControl.ResumeLayout(False)
        Me.registerTab.ResumeLayout(False)
        Me.registerTab.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents SchoolTabControl As TabControl
    Friend WithEvents TabPg As TabPage
    Friend WithEvents registerTab As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents RTitle As Label
    Friend WithEvents RTelNumLbl As Label
    Friend WithEvents RDobLbl As Label
    Friend WithEvents RLastNmLb As Label
    Friend WithEvents RFirstNmLb As Label
    Friend WithEvents RRegisterBtn As Button
    Friend WithEvents RMaritalStatLbl As Label
    Friend WithEvents RSingleRadioBtn As RadioButton
    Friend WithEvents RMarryRadioBtn As RadioButton
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
End Class
