﻿Public Class driveSchoolForm
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TabResize(sender As Object, e As EventArgs) Handles MyBase.Resize
        SchoolTabControl.Size = Me.Size
    End Sub

    Private Sub MaritalStatusRB(sender As Object, e As EventArgs) Handles MyBase.Resize, RSingleRadioBtn.CheckedChanged, RMarryRadioBtn.CheckedChanged
        If (RMarryRadioBtn.Checked = True) Then
            RSingleRadioBtn.Checked = False
        ElseIf (RSingleRadioBtn.Checked = True) Then
            RMarryRadioBtn.Checked = False
        End If

    End Sub

End Class
