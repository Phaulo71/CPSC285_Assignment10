﻿Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class driveSchoolForm
    Private RPhoneNumber As String
    Private RRealPhoneNumber As String
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CPSC_285_5DataSet.Client' table. You can move, or remove it, as needed.
        Me.ClientTableAdapter.Fill(Me.CPSC_285_5DataSet.Client)

        'Initializes the placeholders
        Me.RegistrationTxBxPlaceHolders()
    End Sub

    'Keeps the tab control the same size as the window
    Private Sub TabResize(sender As Object, e As EventArgs) Handles MyBase.Resize
        SchoolTabControl.Size = Me.Size
    End Sub

    'Makes sure only one radio button is clicked
    Private Sub MaritalStatusRB(sender As Object, e As EventArgs) Handles MyBase.Resize, RSingleRadioBtn.CheckedChanged, RMarryRadioBtn.CheckedChanged
        If (RMarryRadioBtn.Checked = True) Then
            RSingleRadioBtn.Checked = False
        ElseIf (RSingleRadioBtn.Checked = True) Then
            RMarryRadioBtn.Checked = False
        End If
    End Sub

    'Changes the users input into numbers
    Private Sub RegistrationPhoneNumber()
        RPhoneNumber = rPhoneNumTxtBx.Text
        For i = 0 To RPhoneNumber.Length - 1
            If (RPhoneNumber.ToUpper.Chars(i) = "A" Or RPhoneNumber.ToUpper.Chars(i) = "B" Or RPhoneNumber.ToUpper.Chars(i) = "C") Then
                RRealPhoneNumber += "2"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "D" Or RPhoneNumber.ToUpper.Chars(i) = "E" Or RPhoneNumber.ToUpper.Chars(i) = "F") Then
                RRealPhoneNumber += "3"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "G" Or RPhoneNumber.ToUpper.Chars(i) = "H" Or RPhoneNumber.ToUpper.Chars(i) = "I") Then
                RRealPhoneNumber += "4"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "J" Or RPhoneNumber.ToUpper.Chars(i) = "K" Or RPhoneNumber.ToUpper.Chars(i) = "L") Then
                RRealPhoneNumber += "5"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "M" Or RPhoneNumber.ToUpper.Chars(i) = "N" Or RPhoneNumber.ToUpper.Chars(i) = "O") Then
                RRealPhoneNumber += "6"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "P" Or RPhoneNumber.ToUpper.Chars(i) = "Q" Or RPhoneNumber.ToUpper.Chars(i) = "R" Or RPhoneNumber.ToUpper.Chars(i) = "S") Then
                RRealPhoneNumber += "7"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "T" Or RPhoneNumber.ToUpper.Chars(i) = "U" Or RPhoneNumber.ToUpper.Chars(i) = "V") Then
                RRealPhoneNumber += "8"
            ElseIf (RPhoneNumber.ToUpper.Chars(i) = "W" Or RPhoneNumber.ToUpper.Chars(i) = "X" Or RPhoneNumber.ToUpper.Chars(i) = "Y" Or RPhoneNumber.ToUpper.Chars(i) = "Z") Then
                RRealPhoneNumber += "9"
            ElseIf (Char.IsNumber(RPhoneNumber.Chars(i))) Then
                If (RPhoneNumber.Chars(i) <> "1" And i = 0) Then
                    RRealPhoneNumber += "1" & RPhoneNumber.Chars(i)
                Else
                    RRealPhoneNumber += RPhoneNumber.Chars(i)
                End If
            End If
        Next
        MessageBox.Show(RRealPhoneNumber)
    End Sub

    'Placeholders
    Private Sub RegistrationTxBxPlaceHolders()
        rDobTxtBx.Text = "MM-DD-YYYY"
        rDobTxtBx.ForeColor = Color.Gray
        rPhoneNumTxtBx.Text = "#-###-###-####"
        rPhoneNumTxtBx.ForeColor = Color.Gray
    End Sub

    'Gets rid of the place holder for DOB
    Private Sub rDOBFocus(sender As Object, e As EventArgs) Handles rDobTxtBx.Enter
        If (rDobTxtBx.Text = "MM-DD-YYYY") Then
            rDobTxtBx.Text = ""
            rDobTxtBx.ForeColor = Color.Black
        End If
    End Sub

    'Placeholder for Date of Birth text box if nothing is inputed
    Private Sub rDOBFocusLeft(sender As Object, e As EventArgs) Handles rDobTxtBx.Leave
        If (rDobTxtBx.Text = "") Then
            rDobTxtBx.Text = "MM-DD-YYYY"
            rDobTxtBx.ForeColor = Color.Gray
        End If
    End Sub

    'Gets rid of the placeholder for Phone Number text box
    Private Sub rphoneNumFocus(sender As Object, e As EventArgs) Handles rPhoneNumTxtBx.Enter
        If (rPhoneNumTxtBx.Text = "#-###-###-####") Then
            rPhoneNumTxtBx.Text = ""
            rPhoneNumTxtBx.ForeColor = Color.Black
        End If
    End Sub

    'Placeholder for phone number if nothing has been inputed
    Private Sub rPhoneNumFocusLeft(sender As Object, e As EventArgs) Handles rPhoneNumTxtBx.Leave
        If (rPhoneNumTxtBx.Text = "") Then
            rPhoneNumTxtBx.Text = "#-###-###-####"
            rPhoneNumTxtBx.ForeColor = Color.Gray
        End If
    End Sub




    Private Sub ClientBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ClientBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ClientBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CPSC_285_5DataSet)

    End Sub

    Private Sub updateClasses()
        InitializeGridView()
        Dim stuID As Int32
        If (ClientIDTextBox.Text <> "") Then
            stuID = ClientIDTextBox.Text
        End If

        Dim cnnDriving As SqlConnection
        Dim strConnect As String = "Data Source=CISSQL;Initial Catalog=CPSC 285_5;Integrated Security=True"
        cnnDriving = New SqlConnection(strConnect)

        Dim cmdClientSchedule As SqlCommand
        Dim rdrSQL As SqlDataReader

        cnnDriving.Open()

        Dim strSql As String = "SELECT Classes.Date, Classes.Time, Staff.Name " &
                               "FROM Classes,Client,Staff " &
                                "WHERE Classes.ClientID = Client.ClientID " &
                                    "AND Classes.StaffID = Staff.StaffID " &
                                    "AND Client.ClientID = " & stuID

        cmdClientSchedule = New SqlCommand(strSql, cnnDriving)

        rdrSQL = cmdClientSchedule.ExecuteReader

        With rdrSQL
            If .HasRows Then
                Do While .Read
                    Dim cDay As DateTime = .Item(0)
                    Dim cTime As TimeSpan = .Item(1)

                    Dim row As String() = {cDay.ToString("d"), cTime.ToString("c"), .Item(2)}
                    gridSchedule.Rows.Add(row)
                Loop
            End If
        End With
    End Sub

    Private Sub InitializeGridView()
        gridSchedule.ColumnCount = 3
        gridSchedule.ColumnHeadersVisible = True

        Dim ColumnHeaderStyle As DataGridViewCellStyle = New DataGridViewCellStyle
        ColumnHeaderStyle.BackColor = Color.Beige
        ColumnHeaderStyle.Font = New Font("Verdana", 10, FontStyle.Bold)
        gridSchedule.ColumnHeadersDefaultCellStyle = ColumnHeaderStyle

        gridSchedule.Columns(0).Name = "Date"
        gridSchedule.Columns(1).Name = "Time"
        gridSchedule.Columns(2).Name = "Instructor"
    End Sub

    Private Sub ClientIDTextBox_TextChanged(sender As Object, e As EventArgs) Handles ClientIDTextBox.TextChanged
        gridSchedule.Rows.Clear()
        updateClasses()
    End Sub

    'Registers the new client if the form is filled
    Private Sub RRegisterBtn_Click(sender As Object, e As EventArgs) Handles RRegisterBtn.Click
        Dim fName As String = rFNameTxtBx.Text
        Dim lName As String = rLNameTxtBx.Text
        Dim name As String = fName & " " & lName
        Dim maritalStat As Boolean
        Dim phoneNum As String
        RegistrationPhoneNumber()

        If (RRealPhoneNumber.Length() <> 0) Then
            If (RRealPhoneNumber.Length() = 11) Then
                phoneNum = Format(Convert.ToInt64(RRealPhoneNumber), "#-(###) ###-####")
            End If
        End If

        If (fName <> "" And lName <> "" And rDobTxtBx.Text <> "MM-DD-YYYY" And rPhoneNumTxtBx.Text <> "#-###-###-####" And RRealPhoneNumber.Length() = 11) Then
            Dim dob As String = CDate(rDobTxtBx.Text).ToString("yyyy-MM-dd")
            Dim cnnClient As SqlConnection
            Dim strConnect As String = "Data Source=CISSQL;Initial Catalog=CPSC 285_5;Integrated Security=True"
            cnnClient = New SqlConnection(strConnect)

            Dim cmdNewClient As SqlCommand
            Dim rdrSQL As SqlDataReader

            If (RMarryRadioBtn.Checked = True) Then
                maritalStat = True
            ElseIf (RSingleRadioBtn.Checked = True) Then
                maritalStat = False
            End If

            Dim strSQL As String = "Insert Into Client (Name, [Marital Status], [Date of Birth], [Phone #]) " &
                               "Values ('" & name & "', '" & maritalStat & "', '" & dob & "', '" & phoneNum & "')"
            Try
                cnnClient = New SqlConnection(strConnect)
                cnnClient.Open()

                cmdNewClient = New SqlCommand
                cmdNewClient.Connection = cnnClient
                cmdNewClient.CommandText = strSQL
                cmdNewClient.CommandType = CommandType.Text

                If (cmdNewClient.ExecuteNonQuery().Equals(1)) Then
                    MessageBox.Show(name & " has been registered.")
                Else
                    MessageBox.Show("Could not register!")
                End If
                cnnClient.Close()
                Me.ClientTableAdapter.Fill(Me.CPSC_285_5DataSet.Client)

                'Rresets the RRealPhoneNumber
                RRealPhoneNumber = ""
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub
End Class

