﻿Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class driveSchoolForm
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CPSC_285_5DataSet.Client' table. You can move, or remove it, as needed.
        Me.ClientTableAdapter.Fill(Me.CPSC_285_5DataSet.Client)

        'Initializes the placeholders
        Me.RegistrationTxBxPlaceHolders()
    End Sub

    'Keeps the tab control the same size as the window
    Private Sub TabResize(sender As Object, e As EventArgs) Handles MyBase.Resize
        SchoolTabControl.Size = Me.Size
    End Sub

    'Makes sure only one radio button is clicked
    Private Sub MaritalStatusRB(sender As Object, e As EventArgs) Handles MyBase.Resize, RSingleRadioBtn.CheckedChanged, RMarryRadioBtn.CheckedChanged
        If (RMarryRadioBtn.Checked = True) Then
            RSingleRadioBtn.Checked = False
        ElseIf (RSingleRadioBtn.Checked = True) Then
            RMarryRadioBtn.Checked = False
        End If
    End Sub

    'Placeholders
    Private Sub RegistrationTxBxPlaceHolders()
        rDobTxtBx.Text = "MM-DD-YYYY"
        rDobTxtBx.ForeColor = Color.Gray
        rPhoneNumTxtBx.Text = "10-digits"
        rPhoneNumTxtBx.ForeColor = Color.Gray
    End Sub

    'Gets rid of the place holder for DOB
    Private Sub rDOBFocus(sender As Object, e As EventArgs) Handles rDobTxtBx.Enter
        If (rDobTxtBx.Text = "MM-DD-YYYY") Then
            rDobTxtBx.Text = ""
            rDobTxtBx.ForeColor = Color.Black
        End If
    End Sub

    'Placeholder for Date of Birth text box if nothing is inputed
    Private Sub rDOBFocusLeft(sender As Object, e As EventArgs) Handles rDobTxtBx.Leave
        If (rDobTxtBx.Text = "") Then
            rDobTxtBx.Text = "MM-DD-YYYY"
            rDobTxtBx.ForeColor = Color.Gray
        End If
    End Sub

    'Gets rid of the placeholder for Phone Number text box
    Private Sub rphoneNumFocus(sender As Object, e As EventArgs) Handles rPhoneNumTxtBx.Enter
        If (rPhoneNumTxtBx.Text = "10-digits") Then
            rPhoneNumTxtBx.Text = ""
            rPhoneNumTxtBx.ForeColor = Color.Black
        End If
    End Sub

    'Placeholder for phone number if nothing has been inputed
    Private Sub rPhoneNumFocusLeft(sender As Object, e As EventArgs) Handles rPhoneNumTxtBx.Leave
        If (rPhoneNumTxtBx.Text = "") Then
            rPhoneNumTxtBx.Text = "10-digits"
            rPhoneNumTxtBx.ForeColor = Color.Gray
        End If
    End Sub




    Private Sub ClientBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ClientBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ClientBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CPSC_285_5DataSet)

    End Sub

    Private Sub updateClasses()
        InitializeGridView()
        Dim stuID As Int32
        If (ClientIDTextBox.Text <> "") Then
            stuID = ClientIDTextBox.Text
        End If

        Dim cnnDriving As SqlConnection
        Dim strConnect As String = "Data Source=CISSQL;Initial Catalog=CPSC 285_5;Integrated Security=True"
        cnnDriving = New SqlConnection(strConnect)

        Dim cmdClientSchedule As SqlCommand
        Dim rdrSQL As SqlDataReader

        cnnDriving.Open()

        Dim strSql As String = "SELECT Classes.Date, Classes.Time, Staff.Name " &
                               "FROM Classes,Client,Staff " &
                                "WHERE Classes.ClientID = Client.ClientID " &
                                    "AND Classes.StaffID = Staff.StaffID " &
                                    "AND Client.ClientID = " & stuID

        cmdClientSchedule = New SqlCommand(strSql, cnnDriving)

        rdrSQL = cmdClientSchedule.ExecuteReader

        With rdrSQL
            If .HasRows Then
                Do While .Read
                    Dim cDay As DateTime = .Item(0)
                    Dim cTime As TimeSpan = .Item(1)

                    Dim row As String() = {cDay.ToString("d"), cTime.ToString("c"), .Item(2)}
                    gridSchedule.Rows.Add(row)
                Loop
            End If
        End With
    End Sub

    Private Sub InitializeGridView()
        gridSchedule.ColumnCount = 3
        gridSchedule.ColumnHeadersVisible = True

        Dim ColumnHeaderStyle As DataGridViewCellStyle = New DataGridViewCellStyle
        ColumnHeaderStyle.BackColor = Color.Beige
        ColumnHeaderStyle.Font = New Font("Verdana", 10, FontStyle.Bold)
        gridSchedule.ColumnHeadersDefaultCellStyle = ColumnHeaderStyle

        gridSchedule.Columns(0).Name = "Date"
        gridSchedule.Columns(1).Name = "Time"
        gridSchedule.Columns(2).Name = "Instructor"
    End Sub

    Private Sub ClientIDTextBox_TextChanged(sender As Object, e As EventArgs) Handles ClientIDTextBox.TextChanged
        gridSchedule.Rows.Clear()
        updateClasses()
    End Sub

    'Registers the new client if the form is filled
    Private Sub RRegisterBtn_Click(sender As Object, e As EventArgs) Handles RRegisterBtn.Click
        Dim fName As String = rFNameTxtBx.Text
        Dim lName As String = rLNameTxtBx.Text
        Dim name As String = fName & " " & lName
        Dim maritalStat As Boolean

        If (fName <> "" And lName <> "" And rDobTxtBx.Text <> "MM-DD-YYYY" And rPhoneNumTxtBx.Text <> "10-digits") Then
            Dim dob As String = CDate(rDobTxtBx.Text).ToString("yyyy-MM-dd")
            Dim phoneNum As String = Format(Convert.ToInt64(rPhoneNumTxtBx.Text), "(###) ###-####")
            Dim cnnClient As SqlConnection
            Dim strConnect As String = "Data Source=CISSQL;Initial Catalog=CPSC 285_5;Integrated Security=True"
            cnnClient = New SqlConnection(strConnect)

            Dim cmdNewClient As SqlCommand
            Dim rdrSQL As SqlDataReader

            If (RMarryRadioBtn.Checked = True) Then
                maritalStat = True
            ElseIf (RSingleRadioBtn.Checked = True) Then
                maritalStat = False
            End If

            Dim strSQL As String = "Insert Into Client (Name, [Marital Status], [Date of Birth], [Phone #]) " &
                               "Values ('" & name & "', '" & maritalStat & "', '" & dob & "', '" & phoneNum & "')"
            Try
                cnnClient = New SqlConnection(strConnect)
                cnnClient.Open()

                cmdNewClient = New SqlCommand
                cmdNewClient.Connection = cnnClient
                cmdNewClient.CommandText = strSQL
                cmdNewClient.CommandType = CommandType.Text

                If (cmdNewClient.ExecuteNonQuery().Equals(1)) Then
                    MessageBox.Show(name & " has been registered.")
                Else
                    MessageBox.Show("Could not register!")
                End If
                cnnClient.Close()
                Me.ClientTableAdapter.Fill(Me.CPSC_285_5DataSet.Client)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub
End Class

