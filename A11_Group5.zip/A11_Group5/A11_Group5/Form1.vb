﻿Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class driveSchoolForm
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CPSC_285_5DataSet.Client' table. You can move, or remove it, as needed.
        Me.ClientTableAdapter.Fill(Me.CPSC_285_5DataSet.Client)

    End Sub

    Private Sub TabResize(sender As Object, e As EventArgs) Handles MyBase.Resize
        SchoolTabControl.Size = Me.Size
    End Sub

    Private Sub MaritalStatusRB(sender As Object, e As EventArgs) Handles MyBase.Resize, RSingleRadioBtn.CheckedChanged, RMarryRadioBtn.CheckedChanged
        If (RMarryRadioBtn.Checked = True) Then
            RSingleRadioBtn.Checked = False
        ElseIf (RSingleRadioBtn.Checked = True) Then
            RMarryRadioBtn.Checked = False
        End If

    End Sub

    Private Sub ClientBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ClientBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ClientBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CPSC_285_5DataSet)

    End Sub

    Private Sub updateClasses()
        InitializeGridView()

        Dim stuID As Int32 = ClientIDTextBox.Text

        Dim cnnDriving As SqlConnection
        Dim strConnect As String = "Data Source=CISSQL;Initial Catalog=CPSC 285_5;Integrated Security=True"
        cnnDriving = New SqlConnection(strConnect)

        Dim cmdClientSchedule As SqlCommand
        Dim rdrSQL As SqlDataReader

        cnnDriving.Open()

        Dim strSql As String = "SELECT Classes.Date, Classes.Time, Staff.Name " &
                               "FROM Classes,Client,Staff " &
                                "WHERE Classes.ClientID = Client.ClientID " &
                                    "AND Classes.StaffID = Staff.StaffID " &
                                    "AND Client.ClientID = " & stuID

        cmdClientSchedule = New SqlCommand(strSql, cnnDriving)

        rdrSQL = cmdClientSchedule.ExecuteReader

        With rdrSQL
            If .HasRows Then
                Do While .Read
                    Dim cDay As DateTime = .Item(0)
                    Dim cTime As TimeSpan = .Item(1)

                    Dim row As String() = {cDay.ToString("d"), cTime.ToString("c"), .Item(2)}
                    gridSchedule.Rows.Add(row)
                Loop
            End If
        End With
    End Sub

    Private Sub InitializeGridView()
        gridSchedule.ColumnCount = 3
        gridSchedule.ColumnHeadersVisible = True

        Dim ColumnHeaderStyle As DataGridViewCellStyle = New DataGridViewCellStyle
        ColumnHeaderStyle.BackColor = Color.Beige
        ColumnHeaderStyle.Font = New Font("Verdana", 10, FontStyle.Bold)
        gridSchedule.ColumnHeadersDefaultCellStyle = ColumnHeaderStyle

        gridSchedule.Columns(0).Name = "Date"
        gridSchedule.Columns(1).Name = "Time"
        gridSchedule.Columns(2).Name = "Instructor"
    End Sub

    Private Sub ClientIDTextBox_TextChanged(sender As Object, e As EventArgs) Handles ClientIDTextBox.TextChanged
        gridSchedule.Rows.Clear()
        updateClasses()
    End Sub
End Class

